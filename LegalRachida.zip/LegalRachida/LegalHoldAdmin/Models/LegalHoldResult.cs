namespace LegalHoldAdmin.Models;

public sealed class LegalHoldResult
{
    public int LegalHoldId { get; set; }
    public string HoldNumber { get; set; } = string.Empty;
    public string CustomerNumber { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string MatterName { get; set; } = string.Empty;
    public string HoldType { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public DateTime IssuedDate { get; set; }
    public DateTime? ReleasedDate { get; set; }
    public string Owner { get; set; } = string.Empty;
}
