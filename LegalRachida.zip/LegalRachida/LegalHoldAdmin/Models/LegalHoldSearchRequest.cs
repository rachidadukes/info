namespace LegalHoldAdmin.Models;

public sealed class LegalHoldSearchRequest
{
    public string? SearchText { get; set; }
    public string? Status { get; set; }
    public string? CustomerNumber { get; set; }
    public DateTime? IssuedFrom { get; set; }
    public DateTime? IssuedTo { get; set; }
}
