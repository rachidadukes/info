namespace LegalHoldAdmin.Models;

public sealed class CustomerSearchResult
{
    public int CustomerId { get; set; }
    public string CustomerNumber { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string RelationshipManager { get; set; } = string.Empty;
    public int ActiveLegalHolds { get; set; }
}
