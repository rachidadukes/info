using System.ComponentModel.DataAnnotations;

namespace LegalHoldAdmin.Models;

public sealed class LegalHoldEditModel
{
    public int? LegalHoldId { get; set; }

    [Required]
    [StringLength(40)]
    public string HoldNumber { get; set; } = string.Empty;

    [Required]
    [StringLength(20)]
    public string CustomerNumber { get; set; } = string.Empty;

    [Required]
    [StringLength(120)]
    public string CustomerName { get; set; } = string.Empty;

    [Required]
    [StringLength(160)]
    public string MatterName { get; set; } = string.Empty;

    [Required]
    [StringLength(40)]
    public string HoldType { get; set; } = "Litigation";

    [Required]
    [StringLength(30)]
    public string Status { get; set; } = "Active";

    public DateTime IssuedDate { get; set; } = DateTime.Today;
    public DateTime? ReleasedDate { get; set; }

    [StringLength(80)]
    public string Owner { get; set; } = string.Empty;

    [StringLength(500)]
    public string Notes { get; set; } = string.Empty;
}
