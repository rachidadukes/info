using LegalHoldAdmin.Models;

namespace LegalHoldAdmin.Data;

public interface ILegalHoldRepository
{
    Task<IReadOnlyList<CustomerSearchResult>> SearchCustomersAsync(string? searchText);
    Task<IReadOnlyList<LegalHoldResult>> SearchLegalHoldsAsync(LegalHoldSearchRequest request);
    Task<LegalHoldEditModel?> GetLegalHoldAsync(int id);
    Task<LegalHoldEditModel> SaveLegalHoldAsync(LegalHoldEditModel model);
    Task ReleaseLegalHoldAsync(int id);
}
