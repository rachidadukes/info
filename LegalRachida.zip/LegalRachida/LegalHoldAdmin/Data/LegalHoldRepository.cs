using LegalHoldAdmin.Models;

namespace LegalHoldAdmin.Data;

public sealed class LegalHoldRepository : ILegalHoldRepository
{
    private readonly List<CustomerSearchResult> customers =
    [
        new()
        {
            CustomerId = 1001,
            CustomerNumber = "C-10482",
            FullName = "Avery Stone",
            Email = "avery.stone@example.com",
            Phone = "555-0142",
            RelationshipManager = "M. Alvarez",
            ActiveLegalHolds = 2
        },
        new()
        {
            CustomerId = 1002,
            CustomerNumber = "C-10844",
            FullName = "Northlake Holdings",
            Email = "legal@northlake.example",
            Phone = "555-0199",
            RelationshipManager = "S. Chen",
            ActiveLegalHolds = 1
        },
        new()
        {
            CustomerId = 1003,
            CustomerNumber = "C-11908",
            FullName = "Riverbend Trust",
            Email = "records@riverbend.example",
            Phone = "555-0177",
            RelationshipManager = "D. Patel",
            ActiveLegalHolds = 0
        }
    ];

    private readonly List<LegalHoldEditModel> legalHolds =
    [
        new()
        {
            LegalHoldId = 1,
            HoldNumber = "LH-2026-0001",
            CustomerNumber = "C-10482",
            CustomerName = "Avery Stone",
            MatterName = "Stone v. Marketplace Services",
            HoldType = "Litigation",
            Status = "Active",
            IssuedDate = new DateTime(2026, 2, 14),
            Owner = "Legal Ops"
        },
        new()
        {
            LegalHoldId = 2,
            HoldNumber = "LH-2026-0002",
            CustomerNumber = "C-10844",
            CustomerName = "Northlake Holdings",
            MatterName = "Regulatory inquiry",
            HoldType = "Regulatory",
            Status = "Active",
            IssuedDate = new DateTime(2026, 5, 3),
            Owner = "Compliance"
        },
        new()
        {
            LegalHoldId = 3,
            HoldNumber = "LH-2025-0041",
            CustomerNumber = "C-10482",
            CustomerName = "Avery Stone",
            MatterName = "Contract retention review",
            HoldType = "Investigation",
            Status = "Released",
            IssuedDate = new DateTime(2025, 11, 22),
            ReleasedDate = new DateTime(2026, 4, 10),
            Owner = "Legal Ops"
        }
    ];

    public Task<IReadOnlyList<CustomerSearchResult>> SearchCustomersAsync(string? searchText)
    {
        var query = Normalize(searchText);
        var results = customers
            .Where(customer => string.IsNullOrWhiteSpace(query)
                || Normalize(customer.CustomerNumber).Contains(query)
                || Normalize(customer.FullName).Contains(query)
                || Normalize(customer.Email).Contains(query))
            .OrderBy(customer => customer.FullName)
            .ToList();

        return Task.FromResult<IReadOnlyList<CustomerSearchResult>>(results);
    }

    public Task<IReadOnlyList<LegalHoldResult>> SearchLegalHoldsAsync(LegalHoldSearchRequest request)
    {
        var query = Normalize(request.SearchText);
        var customerNumber = Normalize(request.CustomerNumber);
        var results = legalHolds
            .Where(hold => string.IsNullOrWhiteSpace(query)
                || Normalize(hold.HoldNumber).Contains(query)
                || Normalize(hold.CustomerName).Contains(query)
                || Normalize(hold.CustomerNumber).Contains(query)
                || Normalize(hold.MatterName).Contains(query))
            .Where(hold => string.IsNullOrWhiteSpace(request.Status) || hold.Status == request.Status)
            .Where(hold => string.IsNullOrWhiteSpace(customerNumber) || Normalize(hold.CustomerNumber).Contains(customerNumber))
            .Where(hold => request.IssuedFrom is null || hold.IssuedDate >= request.IssuedFrom.Value.Date)
            .Where(hold => request.IssuedTo is null || hold.IssuedDate <= request.IssuedTo.Value.Date)
            .OrderByDescending(hold => hold.IssuedDate)
            .Select(ToResult)
            .ToList();

        return Task.FromResult<IReadOnlyList<LegalHoldResult>>(results);
    }

    public Task<LegalHoldEditModel?> GetLegalHoldAsync(int id)
    {
        var hold = legalHolds.FirstOrDefault(item => item.LegalHoldId == id);
        return Task.FromResult(hold is null ? null : Clone(hold));
    }

    public Task<LegalHoldEditModel> SaveLegalHoldAsync(LegalHoldEditModel model)
    {
        if (model.LegalHoldId is null)
        {
            model.LegalHoldId = legalHolds.Max(hold => hold.LegalHoldId) + 1;
            model.HoldNumber = string.IsNullOrWhiteSpace(model.HoldNumber)
                ? $"LH-{DateTime.Today:yyyy}-{model.LegalHoldId:0000}"
                : model.HoldNumber;
            legalHolds.Add(Clone(model));
            return Task.FromResult(Clone(model));
        }

        var existing = legalHolds.FirstOrDefault(hold => hold.LegalHoldId == model.LegalHoldId);
        if (existing is not null)
        {
            legalHolds.Remove(existing);
        }

        legalHolds.Add(Clone(model));
        return Task.FromResult(Clone(model));
    }

    public Task ReleaseLegalHoldAsync(int id)
    {
        var hold = legalHolds.FirstOrDefault(item => item.LegalHoldId == id);
        if (hold is not null)
        {
            hold.Status = "Released";
            hold.ReleasedDate = DateTime.Today;
        }

        return Task.CompletedTask;
    }

    public static IReadOnlyList<string> HoldStatuses { get; } = ["Active", "Released", "Pending Review"];

    public static IReadOnlyList<string> HoldTypes { get; } = ["Litigation", "Regulatory", "Investigation", "Audit"];

    private static LegalHoldResult ToResult(LegalHoldEditModel model) => new()
    {
        LegalHoldId = model.LegalHoldId.GetValueOrDefault(),
        HoldNumber = model.HoldNumber,
        CustomerNumber = model.CustomerNumber,
        CustomerName = model.CustomerName,
        MatterName = model.MatterName,
        HoldType = model.HoldType,
        Status = model.Status,
        IssuedDate = model.IssuedDate,
        ReleasedDate = model.ReleasedDate,
        Owner = model.Owner
    };

    private static LegalHoldEditModel Clone(LegalHoldEditModel model) => new()
    {
        LegalHoldId = model.LegalHoldId,
        HoldNumber = model.HoldNumber,
        CustomerNumber = model.CustomerNumber,
        CustomerName = model.CustomerName,
        MatterName = model.MatterName,
        HoldType = model.HoldType,
        Status = model.Status,
        IssuedDate = model.IssuedDate,
        ReleasedDate = model.ReleasedDate,
        Owner = model.Owner,
        Notes = model.Notes
    };

    private static string Normalize(string? value) => value?.Trim().ToUpperInvariant() ?? string.Empty;
}
