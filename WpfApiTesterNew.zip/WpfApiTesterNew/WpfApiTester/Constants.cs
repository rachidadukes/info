namespace WpfApiTester;

public static class UrlTypes
{
    public const string Transaction    = "Transaction";
    public const string SearchForMember = "SearchForMember";
    public const string MemberProfile  = "MemberProfile";
}
