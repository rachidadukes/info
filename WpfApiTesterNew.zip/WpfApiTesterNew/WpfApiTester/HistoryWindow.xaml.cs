using Microsoft.Data.Sqlite;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Xml;
using System.Xml.Linq;

namespace WpfApiTester;

public partial class HistoryWindow : Window
{
    private readonly string _databasePath;
    private readonly ObservableCollection<RequestItem> _requests = [];
    private readonly ObservableCollection<ResponseEntry> _responses = [];

    public HistoryWindow(string databasePath)
    {
        InitializeComponent();
        _databasePath = databasePath;
        HistoryListBox.ItemsSource = _requests;
        ResponsesListBox.ItemsSource = _responses;
        Loaded += async (_, _) => await LoadRequestsAsync();
    }

    private async Task LoadRequestsAsync()
    {
        _requests.Clear();
        if (!File.Exists(_databasePath)) return;

        try
        {
            await using var connection = new SqliteConnection($"Data Source={_databasePath}");
            await connection.OpenAsync();

            const string sql = "SELECT ID, Description, Request FROM Requests ORDER BY ID";
            await using var command = new SqliteCommand(sql, connection);
            await using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                _requests.Add(new RequestItem(
                    reader.GetInt32(0),
                    reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                    reader.IsDBNull(2) ? string.Empty : reader.GetString(2)));
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Error Loading Requests", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void HistoryListBox_OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        _responses.Clear();
        RequestDetailTextBox.Clear();
        ResponseDetailTextBox.Clear();
        TimestampLabel.Text = "— select a response above";
        StatusLabel.Text = string.Empty;

        if (HistoryListBox.SelectedItem is not RequestItem item) return;

        await LoadResponsesAsync(item.Description);
    }

    private async Task LoadResponsesAsync(string description)
    {
        if (!File.Exists(_databasePath)) return;

        try
        {
            await using var connection = new SqliteConnection($"Data Source={_databasePath}");
            await connection.OpenAsync();

            const string sql = """
                SELECT Request, Response, DateStamp, StatusCode, StatusPhrase
                FROM Responses
                WHERE Description = @description
                ORDER BY rowid DESC
                """;

            await using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@description", (object?)description ?? DBNull.Value);
            await using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                var requestBody  = reader.IsDBNull(0) ? string.Empty : reader.GetString(0);
                var responseBody = reader.IsDBNull(1) ? string.Empty : reader.GetString(1);
                var dateStamp    = reader.IsDBNull(2) ? string.Empty : reader.GetString(2);
                int? statusCode  = reader.IsDBNull(3) ? null : reader.GetInt32(3);
                var statusPhrase = reader.IsDBNull(4) ? null : reader.GetString(4);

                _responses.Add(new ResponseEntry(requestBody, responseBody, dateStamp, statusCode, statusPhrase));
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Error Loading Responses", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ResponsesListBox_OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (ResponsesListBox.SelectedItem is not ResponseEntry entry)
        {
            RequestDetailTextBox.Clear();
            ResponseDetailTextBox.Clear();
            TimestampLabel.Text = "— select a response above";
            StatusLabel.Text = string.Empty;
            return;
        }

        TimestampLabel.Text = entry.DateStamp;
        StatusLabel.Text = entry.StatusCode.HasValue ? $"  |  {entry.StatusCode} {entry.StatusPhrase}" : string.Empty;
        RequestDetailTextBox.Text = FormatXmlIfPossible(entry.RequestBody);
        ResponseDetailTextBox.Text = FormatXmlIfPossible(entry.ResponseBody);
    }

    private static string FormatXmlIfPossible(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return text;

        try
        {
            using var stringReader = new StringReader(text.Trim());
            using var xmlReader = XmlReader.Create(stringReader, new XmlReaderSettings { IgnoreWhitespace = true });
            var document = XDocument.Load(xmlReader, LoadOptions.None);
            var settings = new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "  ",
                NewLineChars = Environment.NewLine,
                NewLineHandling = NewLineHandling.Replace,
                OmitXmlDeclaration = document.Declaration is null
            };
            using var sw = new System.IO.StringWriter();
            using var xw = XmlWriter.Create(sw, settings);
            document.Save(xw);
            xw.Flush();
            return sw.ToString();
        }
        catch
        {
            return text;
        }
    }
}

public sealed class RequestItem(int id, string description, string requestBody)
{
    public int Id { get; } = id;
    public string Description { get; } = description;
    public string RequestBody { get; } = requestBody;
    public string DisplayText => string.IsNullOrWhiteSpace(Description) ? $"Request {Id}" : $"{Id} - {Description}";
}

public sealed class ResponseEntry(
    string requestBody,
    string responseBody,
    string dateStamp,
    int? statusCode,
    string? statusPhrase)
{
    public string RequestBody  { get; } = requestBody;
    public string ResponseBody { get; } = responseBody;
    public string DateStamp    { get; } = dateStamp;
    public int?   StatusCode   { get; } = statusCode;
    public string? StatusPhrase { get; } = statusPhrase;
    public bool IsSuccess => StatusCode is >= 200 and <= 299;
    public string StatusBadge => IsSuccess ? "OK" : "FAIL";
    public Brush StatusColor => IsSuccess
        ? new SolidColorBrush(Color.FromRgb(21, 128, 61))
        : new SolidColorBrush(Color.FromRgb(185, 28, 28));
    public string DisplayText => string.IsNullOrWhiteSpace(DateStamp) ? "(no date)" : DateStamp;
}
