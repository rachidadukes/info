using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Windows;

namespace WpfApiTester;

public partial class MainWindow
{
    private async Task CDdepositAPIAsync()
    {
        var requestBody = GetRichTextBoxText(SelectedRequestRichTextBox);

        if (string.IsNullOrWhiteSpace(requestBody))
        {
            MessageBox.Show("Select a request before calling the API.", "No Request Selected", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (UrlListBox.SelectedItem is not UrlItem selectedUrl || string.IsNullOrWhiteSpace(selectedUrl.Endpoint))
        {
            MessageBox.Show("Select an endpoint before calling the API.", "No Endpoint Selected", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var apiUrl = selectedUrl.Endpoint;
        var description = (RequestsListBox.SelectedItem as RequestListItem)?.Description ?? string.Empty;

        SendButton.IsEnabled         = false;
        MemberSearchButton.IsEnabled = false;
        MemberInfoButton.IsEnabled   = false;
        StatusTextBlock.Text = "Sending request...";

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, apiUrl);
            using var xmlContent = new StringContent(requestBody, Encoding.UTF8, "application/xml");
            xmlContent.Headers.ContentType = new MediaTypeHeaderValue("application/xml");
            request.Headers.Accept.Clear();
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xml"));
            request.Content = xmlContent;

            using var response = await _httpClient.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            StatusTextBlock.Text = $"Completed: {(int)response.StatusCode} {response.ReasonPhrase}";
            ResponseTextBox.Text = FormatXmlIfPossible(responseBody);
            ResponseTab.IsSelected = true;

            var entry = new ApiCallHistory(DateTime.Now, description, requestBody, responseBody,
                (int)response.StatusCode, response.ReasonPhrase, response.IsSuccessStatusCode);
            await SaveResponseAsync(entry);

            var messageText = response.IsSuccessStatusCode
                ? "The API call completed. Check the Response tab for details."
                : "The API call failed. Check the Response tab for details.";
            var caption = response.IsSuccessStatusCode ? "API Call Complete" : "API Call Failed";
            var icon = response.IsSuccessStatusCode ? MessageBoxImage.Information : MessageBoxImage.Warning;

            MessageBox.Show(messageText, caption, MessageBoxButton.OK, icon);
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = "Request failed";
            ResponseTextBox.Text = ex.ToString();
            ResponseTab.IsSelected = true;

            var entry = new ApiCallHistory(DateTime.Now, description, requestBody, ex.ToString(),
                null, "Exception", false);
            await SaveResponseAsync(entry);

            MessageBox.Show("The API call failed. Check the Response tab for details.", "API Call Failed", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            // Re-enable whichever button matches the currently selected type
            var type = (UrlListBox.SelectedItem as UrlItem)?.Type ?? string.Empty;
            SendButton.IsEnabled         = string.Equals(type, UrlTypes.Transaction,     StringComparison.OrdinalIgnoreCase);
            MemberSearchButton.IsEnabled = string.Equals(type, UrlTypes.SearchForMember, StringComparison.OrdinalIgnoreCase);
            MemberInfoButton.IsEnabled   = string.Equals(type, UrlTypes.MemberProfile,   StringComparison.OrdinalIgnoreCase);
        }
    }
}
