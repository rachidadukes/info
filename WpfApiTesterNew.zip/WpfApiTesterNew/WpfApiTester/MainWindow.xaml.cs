using Microsoft.Data.Sqlite;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Net.Http.Headers;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml;
using System.Xml.Linq;

namespace WpfApiTester;

public partial class MainWindow : Window
{
    private const string DefaultApiUrl = "https://swvdcdvencaej01.nfcu.net:8443/EncoreCore/api/MessageConverter/ConvertMessage";

    private readonly HttpClient _httpClient = new()
    {
        Timeout = TimeSpan.FromSeconds(60)
    };

    private readonly string _databasePath1 = Path.Combine(AppContext.BaseDirectory, "Requests.sqlite");
    private readonly string _databasePath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, @"..\..\..\Requests.sqlite"));

    private readonly ObservableCollection<RequestListItem> _requests = [];
    private readonly ObservableCollection<UrlItem> _urls = [];

    // Holds the raw XML of the currently selected request for the API call
    private string _currentRequestBody = string.Empty;

    public MainWindow()
    {
        InitializeComponent();
        RequestsListBox.ItemsSource = _requests;
        UrlListBox.ItemsSource = _urls;
        Loaded += MainWindow_OnLoaded;
    }

    private async void MainWindow_OnLoaded(object sender, RoutedEventArgs e)
    {
        await MigrateResponsesTableAsync();
        await LoadUrlsAsync();           // auto-selects first URL → triggers LoadRequestsAsync
        await HistoryControl.InitializeAsync(_databasePath);
    }

    private async Task LoadUrlsAsync()
    {
        _urls.Clear();
        if (!File.Exists(_databasePath)) return;

        try
        {
            await using var connection = new SqliteConnection($"Data Source={_databasePath}");
            await connection.OpenAsync();

            const string sql = "SELECT ID, Type, Endpoint FROM URL ORDER BY ID";
            await using var command = new SqliteCommand(sql, connection);
            await using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                _urls.Add(new UrlItem(
                    reader.GetInt32(0),
                    reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                    reader.IsDBNull(2) ? string.Empty : reader.GetString(2)));
            }

            if (_urls.Count > 0)
                UrlListBox.SelectedIndex = 0;
            else
                await LoadRequestsAsync(null);   // fallback: load all if URL table is empty
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = $"Warning: could not load URLs — {ex.Message}";
        }
    }

    private async void UrlListBox_OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        var type = (UrlListBox.SelectedItem as UrlItem)?.Type;
        await LoadRequestsAsync(type);
    }

    private async Task MigrateResponsesTableAsync()
    {
        if (!File.Exists(_databasePath)) return;

        try
        {
            await using var connection = new SqliteConnection($"Data Source={_databasePath}");
            await connection.OpenAsync();

            // Add columns to Responses if they don't already exist
            foreach (var ddl in new[]
            {
                "ALTER TABLE Responses ADD COLUMN StatusCode INTEGER",
                "ALTER TABLE Responses ADD COLUMN StatusPhrase TEXT",
                "ALTER TABLE Requests  ADD COLUMN KeyFields   TEXT"
            })
            {
                try
                {
                    await using var cmd = new SqliteCommand(ddl, connection);
                    await cmd.ExecuteNonQueryAsync();
                }
                catch (SqliteException)
                {
                    // Column already exists — safe to ignore
                }
            }

            // Create URL table if it doesn't exist
            const string createUrlTable = """
                CREATE TABLE IF NOT EXISTS URL (
                    ID       INTEGER PRIMARY KEY AUTOINCREMENT,
                    Endpoint TEXT,
                    Type     TEXT
                )
                """;

            await using var createCmd = new SqliteCommand(createUrlTable, connection);
            await createCmd.ExecuteNonQueryAsync();
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = $"Warning: migration failed — {ex.Message}";
        }
    }

    private async Task LoadRequestsAsync(string? type)
    {
        _requests.Clear();
        ClearRequestDisplay();
        ResponseTextBox.Clear();
        StatusTextBlock.Text = "Loading requests...";

        if (!File.Exists(_databasePath))
        {
            StatusTextBlock.Text = "Requests.sqlite was not found.";
            return;
        }

        try
        {
            await using var connection = new SqliteConnection($"Data Source={_databasePath}");
            await connection.OpenAsync();

            var sql = string.IsNullOrWhiteSpace(type)
                ? "SELECT ID, Description, Request FROM Requests ORDER BY ID"
                : "SELECT ID, Description, Request FROM Requests WHERE Type = @type ORDER BY ID";

            await using var command = new SqliteCommand(sql, connection);
            if (!string.IsNullOrWhiteSpace(type))
                command.Parameters.AddWithValue("@type", type);

            await using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                _requests.Add(new RequestListItem(
                    reader.GetInt32(0),
                    reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                    reader.IsDBNull(2) ? string.Empty : reader.GetString(2)));
            }

            StatusTextBlock.Text = $"Loaded {_requests.Count} request(s).";

            if (_requests.Count > 0)
                RequestsListBox.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = "Failed to load requests.";
            MessageBox.Show(ex.Message, "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void RequestsListBox_OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (RequestsListBox.SelectedItem is not RequestListItem selectedItem)
        {
            ClearRequestDisplay();
            return;
        }

        _currentRequestBody = selectedItem.RequestBody;
        DisplayXml(FormatXmlIfPossible(selectedItem.RequestBody));
    }

    // ── RichTextBox helpers ──────────────────────────────────────────────────

    // Matches a line like:   <CustPermId>19537</CustPermId>
    // Group 1 = "<CustPermId>"  Group 2 = "19537"  Group 3 = "</CustPermId>"
    private static readonly Regex LeafElementRegex = new(
        @"^(\s*<[A-Za-z][^>]*>)([^<]+)(<\/[A-Za-z][^>]*>)\s*$",
        RegexOptions.Compiled);

    // Element names whose tags are always rendered blue and bold
    private static readonly HashSet<string> KeyElementNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "CustPermId",
        "TranCode"
    };

    private void ClearRequestDisplay()
    {
        _currentRequestBody = string.Empty;
        SelectedRequestRichTextBox.Document.Blocks.Clear();
    }

    private void DisplayXml(string xml)
    {
        SelectedRequestRichTextBox.Document.Blocks.Clear();
        if (string.IsNullOrWhiteSpace(xml)) return;

        var blue = new SolidColorBrush(Color.FromRgb(180, 0, 0));
        var paragraph = new Paragraph { Margin = new Thickness(0), LineHeight = 1 };
        var lines = xml.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);

        for (var i = 0; i < lines.Length; i++)
        {
            var line = lines[i];
            var match = LeafElementRegex.Match(line);

            if (match.Success)
            {
                var nameMatch = Regex.Match(match.Groups[1].Value.TrimStart(), @"<([A-Za-z][A-Za-z0-9_]*)");
                var elementName = nameMatch.Success ? nameMatch.Groups[1].Value : string.Empty;
                var isBlue = KeyElementNames.Contains(elementName);

                paragraph.Inlines.Add(new Run(match.Groups[1].Value)   // opening tag
                {
                    FontWeight = isBlue ? FontWeights.Bold : FontWeights.Normal,
                    Foreground = isBlue ? blue : Brushes.Black
                });
                paragraph.Inlines.Add(new Run(match.Groups[2].Value)   // value — always bold black
                {
                    FontWeight = FontWeights.Bold
                });
                paragraph.Inlines.Add(new Run(match.Groups[3].Value)   // closing tag
                {
                    FontWeight = isBlue ? FontWeights.Bold : FontWeights.Normal,
                    Foreground = isBlue ? blue : Brushes.Black
                });
            }
            else
            {
                paragraph.Inlines.Add(new Run(line));
            }

            if (i < lines.Length - 1)
                paragraph.Inlines.Add(new LineBreak());
        }

        SelectedRequestRichTextBox.Document.Blocks.Add(paragraph);
    }

    private static string GetRichTextBoxText(System.Windows.Controls.RichTextBox rtb) =>
        new TextRange(rtb.Document.ContentStart, rtb.Document.ContentEnd).Text.TrimEnd();

    // ── API call ─────────────────────────────────────────────────────────────

    private async void SendButton_OnClick(object sender, RoutedEventArgs e)
    {
        var requestBody = GetRichTextBoxText(SelectedRequestRichTextBox);

        if (string.IsNullOrWhiteSpace(requestBody))
        {
            MessageBox.Show("Select a request before calling the API.", "No Request Selected", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        if (UrlListBox.SelectedItem is not UrlItem selectedUrl || string.IsNullOrWhiteSpace(selectedUrl.Endpoint))
        {
            MessageBox.Show("Select an endpoint before calling the API.", "No Endpoint Selected", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var apiUrl = selectedUrl.Endpoint;
        var description = (RequestsListBox.SelectedItem as RequestListItem)?.Description ?? string.Empty;

        SendButton.IsEnabled = false;
        StatusTextBlock.Text = "Sending request...";

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, apiUrl);
            using var xmlContent = new StringContent(requestBody, Encoding.UTF8, "application/xml");
            xmlContent.Headers.ContentType = new MediaTypeHeaderValue("application/xml");
            request.Headers.Accept.Clear();
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xml"));
            request.Content = xmlContent;

            using var response = await _httpClient.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            StatusTextBlock.Text = $"Completed: {(int)response.StatusCode} {response.ReasonPhrase}";
            ResponseTextBox.Text = FormatXmlIfPossible(responseBody);
            ResponseTab.IsSelected = true;

            var entry = new ApiCallHistory(DateTime.Now, description, requestBody, responseBody,
                (int)response.StatusCode, response.ReasonPhrase, response.IsSuccessStatusCode);
            await SaveResponseAsync(entry);

            var messageText = response.IsSuccessStatusCode
                ? "The API call completed. Check the Response tab for details."
                : "The API call failed. Check the Response tab for details.";
            var caption = response.IsSuccessStatusCode ? "API Call Complete" : "API Call Failed";
            var icon = response.IsSuccessStatusCode ? MessageBoxImage.Information : MessageBoxImage.Warning;

            MessageBox.Show(messageText, caption, MessageBoxButton.OK, icon);
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = "Request failed";
            ResponseTextBox.Text = ex.ToString();
            ResponseTab.IsSelected = true;

            var entry = new ApiCallHistory(DateTime.Now, description, requestBody, ex.ToString(),
                null, "Exception", false);
            await SaveResponseAsync(entry);

            MessageBox.Show("The API call failed. Check the Response tab for details.", "API Call Failed", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            SendButton.IsEnabled = true;
        }
    }

    private async Task SaveResponseAsync(ApiCallHistory entry)
    {
        try
        {
            await using var connection = new SqliteConnection($"Data Source={_databasePath}");
            await connection.OpenAsync();

            const string sql = """
                INSERT INTO Responses (Description, Request, Response, DateStamp, StatusCode, StatusPhrase)
                VALUES (@description, @request, @response, @dateStamp, @statusCode, @statusPhrase)
                """;

            await using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@description",  (object?)entry.Description  ?? DBNull.Value);
            command.Parameters.AddWithValue("@request",      (object?)entry.RequestBody   ?? DBNull.Value);
            command.Parameters.AddWithValue("@response",     (object?)entry.ResponseBody  ?? DBNull.Value);
            command.Parameters.AddWithValue("@dateStamp",    entry.Timestamp.ToString("yyyy-MM-dd HH:mm:ss"));
            command.Parameters.AddWithValue("@statusCode",   (object?)entry.StatusCode    ?? DBNull.Value);
            command.Parameters.AddWithValue("@statusPhrase", (object?)entry.StatusPhrase  ?? DBNull.Value);

            await command.ExecuteNonQueryAsync();
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = $"Warning: could not save to Responses table — {ex.Message}";
        }
    }

    private static string FormatXmlIfPossible(string responseText)
    {
        if (string.IsNullOrWhiteSpace(responseText)) return responseText;

        try
        {
            using var stringReader = new StringReader(responseText.Trim());
            using var xmlReader = XmlReader.Create(stringReader, new XmlReaderSettings { IgnoreWhitespace = true });
            var document = XDocument.Load(xmlReader, LoadOptions.None);
            var settings = new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "  ",
                NewLineChars = Environment.NewLine,
                NewLineHandling = NewLineHandling.Replace,
                OmitXmlDeclaration = document.Declaration is null
            };
            using var stringWriter = new StringWriter();
            using var xmlWriter = XmlWriter.Create(stringWriter, settings);
            document.Save(xmlWriter);
            xmlWriter.Flush();
            return stringWriter.ToString();
        }
        catch
        {
            return responseText;
        }
    }

    private sealed record RequestListItem(int Id, string Description, string RequestBody)
    {
        public string DisplayText => string.IsNullOrWhiteSpace(Description)
            ? $"Request {Id}"
            : $"{Id} - {Description}";
    }

    private sealed record UrlItem(int Id, string Type, string Endpoint);
}

public sealed record ApiCallHistory(
    DateTime Timestamp,
    string Description,
    string RequestBody,
    string ResponseBody,
    int? StatusCode,
    string? StatusPhrase,
    bool IsSuccess)
{
    public string DisplayText =>
        $"{Timestamp:HH:mm:ss}  {(StatusCode.HasValue ? $"{StatusCode} {StatusPhrase}" : StatusPhrase)}  {(string.IsNullOrWhiteSpace(Description) ? "(no description)" : Description)}";

    public string StatusBadge => IsSuccess ? "OK" : "FAIL";
}
