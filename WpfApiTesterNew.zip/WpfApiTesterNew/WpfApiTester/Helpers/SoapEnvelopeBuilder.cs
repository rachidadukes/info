﻿using System.Xml.Linq;

namespace WpfApiTester.Helpers
    {
        public static class SoapEnvelopeBuilder
        {
            private static readonly XNamespace SoapEnvNs = "http://schemas.xmlsoap.org/soap/envelope/";
            private static readonly XNamespace NfbNs = "http://schemas.navyfederal.org/2010/04/NFBranchExService";

            /// <summary>
            /// Wraps raw XML inside a SOAP envelope.
            /// </summary>
            /// <param name="innerXml">The XML payload (e.g., SearchMemberRq)</param>
            /// <returns>SOAP-wrapped XML string</returns>
            public static string WrapInSoapEnvelope(string innerXml)
            {
                if (string.IsNullOrWhiteSpace(innerXml))
                    throw new ArgumentException("Inner XML cannot be null or empty.", nameof(innerXml));

                XDocument innerDoc;

                try
                {
                    innerDoc = XDocument.Parse(innerXml);
                }
                catch (Exception ex)
                {
                    throw new InvalidOperationException("Invalid XML provided for SOAP wrapping.", ex);
                }

                var envelope = new XDocument(
                    new XElement(SoapEnvNs + "Envelope",
                        new XAttribute(XNamespace.Xmlns + "soapenv", SoapEnvNs),
                        new XAttribute(XNamespace.Xmlns + "nfb", NfbNs),

                        new XElement(SoapEnvNs + "Header"),

                        new XElement(SoapEnvNs + "Body",
                            innerDoc.Root
                        )
                    )
                );

                return envelope.ToString(SaveOptions.DisableFormatting);
            }
        }
    }

