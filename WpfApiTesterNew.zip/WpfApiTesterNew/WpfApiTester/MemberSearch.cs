using System.Net.Http;
using System.Text;
using WpfApiTester.Helpers;

namespace WpfApiTester;

public class MemberSearch
{
    public async Task<string> ReadXMLresponse(string SoapXMLRequest, string endpoint)
    {
        string mainResponse;
        HttpClient httpClient = new HttpClient();
        try
        {
            string wrappedRequest = SoapEnvelopeBuilder.WrapInSoapEnvelope(SoapXMLRequest);
            var content = new StringContent(wrappedRequest, Encoding.UTF8, "application/xml");
            var response = await httpClient.PostAsync(endpoint, content);
            var responseXMLContent = await response.Content.ReadAsStringAsync();
            mainResponse = responseXMLContent;
            return mainResponse;
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error reading XML Response: " + ex.Message);
            return "";
        }
    }

    public async Task<string> SendSoapRequestAsync(string requestXml, string endpoint)
    {
        using HttpClient httpClient = new HttpClient();

        try
        {
            string soapRequest = requestXml.Contains("<soapenv:Envelope")
                ? requestXml
                : SoapEnvelopeBuilder.WrapInSoapEnvelope(requestXml);

            using var content = new StringContent(soapRequest, Encoding.UTF8, "application/xml");

            var response = await httpClient.PostAsync(endpoint, content);
            var responseXml = await response.Content.ReadAsStringAsync();

            return responseXml;
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error sending SOAP request: " + ex.Message);
            return string.Empty;
        }
    }
}
