using System.Net.Http;
using System.Text;

namespace WpfApiTester;

public class MemberSearch
{
    public async Task<string> ReadXMLresponse(string SoapXMLString, string endpoint)
    {
        string mainResponse;
        HttpClient httpClient = new HttpClient();
        try
        {
            var content = new StringContent(SoapXMLString, Encoding.UTF8, "application/xml");
            var response = await httpClient.PostAsync(endpoint, content);
            var responseXMLContent = await response.Content.ReadAsStringAsync();
            mainResponse = responseXMLContent;
            return mainResponse;
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error reading XML Response: " + ex.Message);
            return "";
        }
    }
}
