﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfApiTester;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
}

