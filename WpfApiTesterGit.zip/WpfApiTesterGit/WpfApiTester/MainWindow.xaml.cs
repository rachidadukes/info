using Microsoft.Data.Sqlite;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Net.Http.Headers;
using System.IO;
using System.Text;
using System.Windows;
using System.Xml;
using System.Xml.Linq;

namespace WpfApiTester;

public partial class MainWindow : Window
{
    private const string DefaultApiUrl = "https://swvdcdvencaej01.nfcu.net:8443/EncoreCore/api/MessageConverter/ConvertMessage";

    private readonly HttpClient _httpClient = new()
    {
        Timeout = TimeSpan.FromSeconds(60)
    };

    private readonly string _databasePath1 = Path.Combine(AppContext.BaseDirectory, "Requests.sqlite");
    private readonly string _databasePath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, @"..\..\..\Requests.sqlite"));

    private readonly ObservableCollection<RequestListItem> _requests = [];
    private readonly List<ApiCallHistory> _history = [];

    public MainWindow()
    {
        InitializeComponent();
        RequestsListBox.ItemsSource = _requests;
        ApiUrlLabel.Content = DefaultApiUrl;
        Loaded += MainWindow_OnLoaded;
    }

    private async void MainWindow_OnLoaded(object sender, RoutedEventArgs e)
    {
        await LoadRequestsAsync();
    }

    private async Task LoadRequestsAsync()
    {
        _requests.Clear();
        SelectedRequestTextBox.Clear();
        ResponseTextBox.Clear();
        StatusTextBlock.Text = "Loading requests...";

        if (!File.Exists(_databasePath))
        {
            StatusTextBlock.Text = "Requests.sqlite was not found.";
            return;
        }

        try
        {
            await using var connection = new SqliteConnection($"Data Source={_databasePath}");
            await connection.OpenAsync();

            const string sql = "SELECT ID, Description, Request FROM Requests ORDER BY ID";
            await using var command = new SqliteCommand(sql, connection);
            await using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                var item = new RequestListItem(
                    reader.GetInt32(0),
                    reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                    reader.IsDBNull(2) ? string.Empty : reader.GetString(2));

                _requests.Add(item);
            }

            StatusTextBlock.Text = $"Loaded {_requests.Count} request(s).";

            if (_requests.Count > 0)
            {
                RequestsListBox.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = "Failed to load requests.";
            MessageBox.Show(ex.Message, "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void RequestsListBox_OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (RequestsListBox.SelectedItem is not RequestListItem selectedItem)
        {
            SelectedRequestTextBox.Clear();
            return;
        }

        SelectedRequestTextBox.Text = FormatXmlIfPossible(selectedItem.RequestBody);
    }

    private async void SendButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(SelectedRequestTextBox.Text))
        {
            MessageBox.Show("Select a request before calling the API.", "No Request Selected", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        var apiUrl = string.IsNullOrWhiteSpace(ApiUrlLabel.Content?.ToString())
            ? DefaultApiUrl
            : ApiUrlLabel.Content.ToString().Trim();

        var description = (RequestsListBox.SelectedItem as RequestListItem)?.Description ?? string.Empty;
        var requestBody = SelectedRequestTextBox.Text;

        SendButton.IsEnabled = false;
        StatusTextBlock.Text = "Sending request...";

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, apiUrl);
            using var xmlContent = new StringContent(requestBody, Encoding.UTF8, "application/xml");
            xmlContent.Headers.ContentType = new MediaTypeHeaderValue("application/xml");
            request.Headers.Accept.Clear();
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xml"));
            request.Content = xmlContent;

            using var response = await _httpClient.SendAsync(request);
            var responseBody = await response.Content.ReadAsStringAsync();

            StatusTextBlock.Text = $"Completed: {(int)response.StatusCode} {response.ReasonPhrase}";
            ResponseTextBox.Text = FormatXmlIfPossible(responseBody);
            ResponseTab.IsSelected = true;

            var entry = new ApiCallHistory(DateTime.Now, description, requestBody, responseBody,
                (int)response.StatusCode, response.ReasonPhrase, response.IsSuccessStatusCode);
            _history.Add(entry);
            await SaveResponseAsync(entry);

            var messageText = response.IsSuccessStatusCode
                ? "The API call completed. Check the Response tab for details."
                : "The API call failed. Check the Response tab for details.";
            var caption = response.IsSuccessStatusCode ? "API Call Complete" : "API Call Failed";
            var icon = response.IsSuccessStatusCode ? MessageBoxImage.Information : MessageBoxImage.Warning;

            MessageBox.Show(messageText, caption, MessageBoxButton.OK, icon);
        }
        catch (Exception ex)
        {
            StatusTextBlock.Text = "Request failed";
            ResponseTextBox.Text = ex.ToString();
            ResponseTab.IsSelected = true;

            var entry = new ApiCallHistory(DateTime.Now, description, requestBody, ex.ToString(),
                null, "Exception", false);
            _history.Add(entry);
            await SaveResponseAsync(entry);

            MessageBox.Show("The API call failed. Check the Response tab for details.", "API Call Failed", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            SendButton.IsEnabled = true;
        }
    }

    private async Task SaveResponseAsync(ApiCallHistory entry)
    {
        try
        {
            await using var connection = new SqliteConnection($"Data Source={_databasePath}");
            await connection.OpenAsync();

            const string sql = """
                INSERT INTO Responses (Description, Request, Response, DateStamp)
                VALUES (@description, @request, @response, @dateStamp)
                """;

            await using var command = new SqliteCommand(sql, connection);
            command.Parameters.AddWithValue("@description", (object?)entry.Description ?? DBNull.Value);
            command.Parameters.AddWithValue("@request",     (object?)entry.RequestBody  ?? DBNull.Value);
            command.Parameters.AddWithValue("@response",    (object?)entry.ResponseBody ?? DBNull.Value);
            command.Parameters.AddWithValue("@dateStamp",   entry.Timestamp.ToString("yyyy-MM-dd HH:mm:ss"));

            await command.ExecuteNonQueryAsync();
        }
        catch (Exception ex)
        {
            // Don't interrupt the user flow — just surface it in the status bar
            StatusTextBlock.Text = $"Warning: could not save to Responses table — {ex.Message}";
        }
    }

    private static string FormatXmlIfPossible(string responseText)
    {
        if (string.IsNullOrWhiteSpace(responseText))
        {
            return responseText;
        }

        try
        {
            using var stringReader = new StringReader(responseText.Trim());
            using var xmlReader = XmlReader.Create(stringReader, new XmlReaderSettings
            {
                IgnoreWhitespace = true
            });

            var document = XDocument.Load(xmlReader, LoadOptions.None);

            var settings = new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "  ",
                NewLineChars = Environment.NewLine,
                NewLineHandling = NewLineHandling.Replace,
                OmitXmlDeclaration = document.Declaration is null
            };

            using var stringWriter = new StringWriter();
            using var xmlWriter = XmlWriter.Create(stringWriter, settings);
            document.Save(xmlWriter);
            xmlWriter.Flush();

            return stringWriter.ToString();
        }
        catch
        {
            return responseText;
        }
    }

    private void HistoryButton_OnClick(object sender, RoutedEventArgs e)
    {
        var window = new HistoryWindow(_history) { Owner = this };
        window.Show();
    }

    private sealed record RequestListItem(int Id, string Description, string RequestBody)
    {
        public string DisplayText => string.IsNullOrWhiteSpace(Description)
            ? $"Request {Id}"
            : $"{Id} - {Description}";
    }
}

public sealed record ApiCallHistory(
    DateTime Timestamp,
    string Description,
    string RequestBody,
    string ResponseBody,
    int? StatusCode,
    string? StatusPhrase,
    bool IsSuccess)
{
    public string DisplayText =>
        $"{Timestamp:HH:mm:ss}  {(StatusCode.HasValue ? $"{StatusCode} {StatusPhrase}" : StatusPhrase)}  {(string.IsNullOrWhiteSpace(Description) ? "(no description)" : Description)}";

    public string StatusBadge => IsSuccess ? "OK" : "FAIL";
}
