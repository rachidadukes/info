using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Xml;
using System.Xml.Linq;

namespace WpfApiTester;

public partial class HistoryWindow : Window
{
    private readonly List<ApiCallHistory> _source;
    private readonly ObservableCollection<HistoryViewModel> _items = [];

    public HistoryWindow(List<ApiCallHistory> history)
    {
        InitializeComponent();
        _source = history;
        HistoryListBox.ItemsSource = _items;
        Refresh();
    }

    private void Refresh()
    {
        _items.Clear();
        // Show newest first
        for (int i = _source.Count - 1; i >= 0; i--)
            _items.Add(new HistoryViewModel(_source[i]));
    }

    private void HistoryListBox_OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (HistoryListBox.SelectedItem is not HistoryViewModel vm)
        {
            RequestDetailTextBox.Clear();
            ResponseDetailTextBox.Clear();
            TimestampLabel.Text = "Select a call to inspect it.";
            StatusLabel.Text = string.Empty;
            return;
        }

        var entry = vm.Entry;
        TimestampLabel.Text = entry.Timestamp.ToString("yyyy-MM-dd  HH:mm:ss");
        StatusLabel.Text = entry.StatusCode.HasValue
            ? $"{entry.StatusCode} {entry.StatusPhrase}"
            : entry.StatusPhrase;
        StatusLabel.Foreground = entry.IsSuccess
            ? new SolidColorBrush(Color.FromRgb(21, 128, 61))
            : new SolidColorBrush(Color.FromRgb(185, 28, 28));

        RequestDetailTextBox.Text = FormatXmlIfPossible(entry.RequestBody);
        ResponseDetailTextBox.Text = FormatXmlIfPossible(entry.ResponseBody);
    }

    private void ClearButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (_source.Count == 0) return;

        var result = MessageBox.Show(
            "Clear all history entries?", "Clear History",
            MessageBoxButton.YesNo, MessageBoxImage.Question);

        if (result != MessageBoxResult.Yes) return;

        _source.Clear();
        _items.Clear();
        RequestDetailTextBox.Clear();
        ResponseDetailTextBox.Clear();
        TimestampLabel.Text = "Select a call to inspect it.";
        StatusLabel.Text = string.Empty;
    }

    private static string FormatXmlIfPossible(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return text;

        try
        {
            using var stringReader = new StringReader(text.Trim());
            using var xmlReader = XmlReader.Create(stringReader, new XmlReaderSettings { IgnoreWhitespace = true });
            var document = XDocument.Load(xmlReader, LoadOptions.None);
            var settings = new XmlWriterSettings
            {
                Indent = true,
                IndentChars = "  ",
                NewLineChars = Environment.NewLine,
                NewLineHandling = NewLineHandling.Replace,
                OmitXmlDeclaration = document.Declaration is null
            };
            using var sw = new System.IO.StringWriter();
            using var xw = XmlWriter.Create(sw, settings);
            document.Save(xw);
            xw.Flush();
            return sw.ToString();
        }
        catch
        {
            return text;
        }
    }
}

public sealed class HistoryViewModel(ApiCallHistory entry)
{
    public ApiCallHistory Entry { get; } = entry;
    public string DisplayText => Entry.DisplayText;
    public string StatusBadge => Entry.StatusBadge;
    public Brush StatusColor => Entry.IsSuccess
        ? new SolidColorBrush(Color.FromRgb(21, 128, 61))
        : new SolidColorBrush(Color.FromRgb(185, 28, 28));
}
