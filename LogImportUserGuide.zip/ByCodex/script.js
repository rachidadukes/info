const systemDetails = {
  import: {
    kicker: "Import system",
    title: "LogsImportApp",
    body: "Imports data from the Encore Logs SQL Server database into a local SQLite database.",
    owns: "Log import from Encore SQL Server",
    database: "LogsImportDB.db",
  },
  extract: {
    kicker: "Extraction system",
    title: "ExtractMemberInfoApp",
    body: "Extracts request and response content from log records for member information processing.",
    owns: "Request and response extraction",
    database: "ExtractMemberInfoDB.db",
  },
  members: {
    kicker: "Member listing system",
    title: "MemberListingApp",
    body: "Extracts member details such as first name and last name from request fields.",
    owns: "Member listing extraction",
    database: "ExtractMemberInfoDB.db",
  },
  transactions: {
    kicker: "Transaction system",
    title: "TransactionsFromLogsApp",
    body: "Extracts request and response details related to transactions from log data.",
    owns: "Transaction detail extraction",
    database: "Log-derived transaction data",
  },
  accounts: {
    kicker: "Account system",
    title: "AccountsApp",
    body: "Extracts account information from request data and stores the results in SQLite.",
    owns: "Account information extraction",
    database: "AccountsDB.db",
  },
};

const progress = document.querySelector(".scroll-progress");
const navLinks = [...document.querySelectorAll("nav a")];
const sections = [...document.querySelectorAll("[data-section]")];
const revealItems = [...document.querySelectorAll(".reveal")];
const orbitButtons = [...document.querySelectorAll(".orbit-node")];

function updateProgress() {
  const scrollable = document.documentElement.scrollHeight - window.innerHeight;
  const percent = scrollable > 0 ? (window.scrollY / scrollable) * 100 : 0;
  progress.style.width = `${percent}%`;
}

function setActiveNav() {
  const current = sections
    .filter((section) => section.getBoundingClientRect().top <= 140)
    .at(-1);

  if (!current) return;

  navLinks.forEach((link) => {
    const isActive = link.getAttribute("href") === `#${current.id}`;
    link.classList.toggle("active", isActive);
  });
}

function updateSystemDetail(key) {
  const detail = systemDetails[key];
  if (!detail) return;

  orbitButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.system === key);
  });
}

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.15 },
);

revealItems.forEach((item) => revealObserver.observe(item));

orbitButtons.forEach((button) => {
  button.addEventListener("click", () => updateSystemDetail(button.dataset.system));
});

window.addEventListener("scroll", () => {
  updateProgress();
  setActiveNav();
});

updateProgress();
setActiveNav();
