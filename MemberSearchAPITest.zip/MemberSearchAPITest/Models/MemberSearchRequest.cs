using System.Text.Json.Serialization;

namespace MemberSearchSpectreTest.Models;

public sealed class MemberSearchRequest
{
    [JsonPropertyName("NFCURequestHeader")]
    public required NfcuRequestHeader NFCURequestHeader { get; init; }

    [JsonPropertyName("membershipType")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? MembershipType { get; init; }

    [JsonPropertyName("ssn")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Ssn { get; init; }

    [JsonPropertyName("phoneNumber")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? PhoneNumber { get; init; }

    [JsonPropertyName("firstName")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? FirstName { get; init; }

    [JsonPropertyName("middleName")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? MiddleName { get; init; }

    [JsonPropertyName("lastName")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? LastName { get; init; }
}

public sealed class NfcuRequestHeader
{
    [JsonPropertyName("rqUID")]
    public required string RqUID { get; init; }

    [JsonPropertyName("credential")]
    public required string Credential { get; init; }

    [JsonPropertyName("consumerChannel")]
    public required string ConsumerChannel { get; init; }

    [JsonPropertyName("consumingApplicationName")]
    public required string ConsumingApplicationName { get; init; }
}
