# Encore Deployment Coordination

.NET 10 Blazor Web App with global Interactive Server rendering and Radzen.Blazor using the free Material theme.

Open Encore.DeploymentCoordination.slnx in Visual Studio with .NET 10 support.

Run from this folder:

```powershell
dotnet run --project Encore.DeploymentCoordination.Web
```

Use the localhost URL printed by the application. HTTPS launch profiles are included.

The prototype includes Overview, Deployments, Test machines, and Testing windows pages with illustrative sample data. Radzen grids support sorting and deployment/machine filtering. Testing windows can be filtered to conflicts only. Shared-machine overlaps are detected across group membership; back-to-back windows are allowed. This rule is proposed for Jake and John to review. Authentication, persistence, reservation enforcement, code/policy verification, and pipeline integration are not yet implemented.

