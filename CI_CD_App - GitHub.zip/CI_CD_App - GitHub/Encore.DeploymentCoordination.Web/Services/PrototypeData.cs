namespace Encore.DeploymentCoordination.Web.Services;

public record Deployment(string Id, string Type, string Release, string Build, string Environment, string Policy, string Scope)
{
    public string Purpose { get; init; } = "Not specified";
}
public enum GlobalProtectClassification { Unknown, GlobalProtect, NonGlobalProtect }
public record Machine(string Name, string Environment, string Policy, string Build, string[] Groups)
{
    public string Location { get; init; } = "Unknown";
    public string Configuration { get; init; } = "Not recorded";
    public GlobalProtectClassification GlobalProtect { get; init; }
    public bool? ProductionAligned { get; init; }
    public bool? PreviousIntegrationBaseline { get; init; }
    public string ProductionAlignment => Describe(ProductionAligned);
    public string IntegrationBaseline => Describe(PreviousIntegrationBaseline);
    public string NetworkClassification => GlobalProtect switch
    {
        GlobalProtectClassification.GlobalProtect => "GlobalProtect",
        GlobalProtectClassification.NonGlobalProtect => "Non-GlobalProtect",
        _ => "Unknown"
    };
    private static string Describe(bool? value) => value switch { true => "Yes", false => "No", null => "Unknown" };
}
public record TestWindow(string Id, string DeploymentId, string Activity, string Owner, DateTimeOffset Start, DateTimeOffset End, string[] Machines, string[] Groups);
public record WindowConflict(TestWindow First, TestWindow Second, string[] Machines);

public class PrototypeData
{
    public IReadOnlyList<Deployment> Deployments { get; } = [
        new("DEP-001", "INTG_ALT", "Encore 26.2", "26.2.104", "Test", "Integration", "SQA pool") { Purpose = "Integration testing of combined changes before business acceptance." },
        new("DEP-002", "UAT", "Encore 26.2", "26.2.108", "Test", "Acceptance", "UAT pool") { Purpose = "Business acceptance testing of the candidate release." },
        new("DEP-003", "STAGE", "Encore 26.2", "26.2.108", "Staging", "Release candidate", "STAGE-01") { Purpose = "Release candidate verification in staging." }
    ];
    public IReadOnlyList<Machine> Machines { get; } = [
        new("TEST-01", "Test", "Integration", "26.2.104", ["SQA pool"]) { Location = "Sample lab A", GlobalProtect = GlobalProtectClassification.NonGlobalProtect, ProductionAligned = false, PreviousIntegrationBaseline = true, Configuration = "Illustrative retained integration baseline; actual setup not recorded." },
        new("TEST-02", "Test", "Integration", "26.2.104", ["SQA pool", "UAT pool"]) { Location = "Sample lab A", GlobalProtect = GlobalProtectClassification.GlobalProtect, ProductionAligned = false, PreviousIntegrationBaseline = false },
        new("TEST-03", "Test", "Acceptance", "26.2.108", ["UAT pool"]) { Location = "Sample lab B", GlobalProtect = GlobalProtectClassification.NonGlobalProtect, ProductionAligned = true, PreviousIntegrationBaseline = false, Configuration = "Illustrative production-aligned machine; alignment criteria not yet defined." },
        new("STAGE-01", "Staging", "Release candidate", "26.2.108", [])
    ];
    public IReadOnlyList<TestWindow> Windows { get; } = [
        new("WIN-001", "DEP-001", "SQA", "John", new(2026,10,14,9,0,0,TimeSpan.FromHours(-4)), new(2026,10,14,12,0,0,TimeSpan.FromHours(-4)), [], ["SQA pool"]),
        new("WIN-002", "DEP-002", "UAT", "Acceptance team", new(2026,10,14,11,0,0,TimeSpan.FromHours(-4)), new(2026,10,14,15,0,0,TimeSpan.FromHours(-4)), [], ["UAT pool"]),
        new("WIN-003", "DEP-003", "SQA", "John", new(2026,10,15,9,0,0,TimeSpan.FromHours(-4)), new(2026,10,15,11,0,0,TimeSpan.FromHours(-4)), ["STAGE-01"], [])
    ];
    public string[] ResolveMachines(TestWindow window) => window.Machines.Concat(Machines.Where(m => m.Groups.Intersect(window.Groups, StringComparer.OrdinalIgnoreCase).Any()).Select(m => m.Name)).Distinct(StringComparer.OrdinalIgnoreCase).Order().ToArray();
    public IReadOnlyList<WindowConflict> Conflicts => Windows.SelectMany((a, index) => Windows.Skip(index + 1).Where(b => a.Start < b.End && b.Start < a.End).Select(b => new WindowConflict(a, b, ResolveMachines(a).Intersect(ResolveMachines(b), StringComparer.OrdinalIgnoreCase).ToArray()))).Where(c => c.Machines.Length > 0).ToArray();
    public bool HasConflict(TestWindow window) => Conflicts.Any(c => c.First.Id == window.Id || c.Second.Id == window.Id);
}
