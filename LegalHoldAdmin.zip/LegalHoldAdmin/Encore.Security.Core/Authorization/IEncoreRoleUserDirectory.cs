using Encore.Security.Core.Models;

namespace Encore.Security.Core.Authorization;

public interface IEncoreRoleUserDirectory
{
    Task<IReadOnlyList<EncoreRoleUser>> GetUsersInRoleAsync(
        string role,
        CancellationToken cancellationToken = default);
}
