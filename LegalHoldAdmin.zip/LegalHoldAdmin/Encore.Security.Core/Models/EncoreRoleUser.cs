namespace Encore.Security.Core.Models;

public sealed class EncoreRoleUser
{
    public string EmployeeId { get; init; } = string.Empty;

    public string DisplayName { get; init; } = string.Empty;

    public string DistinguishedName { get; init; } = string.Empty;

    public string Role { get; init; } = string.Empty;

    public int LegacyAuthorityLevel { get; init; }
}
