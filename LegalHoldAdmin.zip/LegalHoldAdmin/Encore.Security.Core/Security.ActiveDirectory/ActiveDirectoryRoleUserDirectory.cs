using System.DirectoryServices.Protocols;
using System.Net;
using Encore.Security.Core.Authorization;
using Encore.Security.Core.Models;
using Encore.Security.Core.Options;
using Microsoft.Extensions.Logging;

namespace Encore.Security.ActiveDirectory;

public sealed class ActiveDirectoryRoleUserDirectory(
    ActiveDirectoryOptions activeDirectoryOptions,
    EncoreAuthorizationOptions authorizationOptions,
    ILogger<ActiveDirectoryRoleUserDirectory> logger) : IEncoreRoleUserDirectory
{
    public async Task<IReadOnlyList<EncoreRoleUser>> GetUsersInRoleAsync(
        string role,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(role))
        {
            return [];
        }

        if (string.IsNullOrWhiteSpace(activeDirectoryOptions.Server) ||
            string.IsNullOrWhiteSpace(activeDirectoryOptions.SearchBaseDn))
        {
            logger.LogWarning("Active Directory role user lookup is not configured.");
            return [];
        }

        var mapping = authorizationOptions.GroupMappings
            .OrderBy(candidate => candidate.Precedence)
            .FirstOrDefault(candidate => string.Equals(
                candidate.Role,
                role,
                StringComparison.OrdinalIgnoreCase));

        if (mapping is null)
        {
            return [];
        }

        try
        {
            var identifier = new LdapDirectoryIdentifier(
                activeDirectoryOptions.Server,
                activeDirectoryOptions.Port);
            using var connection = new LdapConnection(identifier)
            {
                AuthType = activeDirectoryOptions.AuthType,
                Credential = CredentialCache.DefaultNetworkCredentials
            };

            connection.SessionOptions.ProtocolVersion = 3;
            connection.SessionOptions.SecureSocketLayer = activeDirectoryOptions.UseSsl;

            await Task.Run(connection.Bind, cancellationToken);

            var memberDns = await GetGroupMemberDnsAsync(connection, mapping, cancellationToken);
            var users = new List<EncoreRoleUser>(memberDns.Count);

            foreach (var memberDn in memberDns)
            {
                var user = await GetUserAsync(connection, memberDn, mapping, cancellationToken);
                if (user is not null)
                {
                    users.Add(user);
                }
            }

            return users
                .OrderBy(user => user.DisplayName)
                .ThenBy(user => user.EmployeeId)
                .ToArray();
        }
        catch (LdapException ex)
        {
            logger.LogWarning(ex, "Active Directory role user lookup failed for role {Role}.", role);
            return [];
        }
        catch (DirectoryOperationException ex)
        {
            logger.LogWarning(ex, "Active Directory role user search failed for role {Role}.", role);
            return [];
        }
    }

    private async Task<IReadOnlyList<string>> GetGroupMemberDnsAsync(
        LdapConnection connection,
        EncoreGroupMapping mapping,
        CancellationToken cancellationToken)
    {
        var request = !string.IsNullOrWhiteSpace(mapping.DistinguishedName)
            ? new SearchRequest(
                mapping.DistinguishedName,
                "(objectClass=*)",
                SearchScope.Base,
                "member")
            : new SearchRequest(
                activeDirectoryOptions.SearchBaseDn,
                $"(&(objectClass=group)(cn={EscapeLdapFilterValue(mapping.GroupName)}))",
                SearchScope.Subtree,
                "member");

        var response = await Task.Run(
            () => (SearchResponse)connection.SendRequest(request),
            cancellationToken);

        if (response.Entries.Count == 0)
        {
            return [];
        }

        return ReadMultiValueAttribute(response.Entries[0], "member");
    }

    private async Task<EncoreRoleUser?> GetUserAsync(
        LdapConnection connection,
        string distinguishedName,
        EncoreGroupMapping mapping,
        CancellationToken cancellationToken)
    {
        var request = new SearchRequest(
            distinguishedName,
            "(objectClass=user)",
            SearchScope.Base,
            activeDirectoryOptions.EmployeeIdAttribute,
            activeDirectoryOptions.DisplayNameAttribute,
            "distinguishedName");

        var response = await Task.Run(
            () => (SearchResponse)connection.SendRequest(request),
            cancellationToken);

        if (response.Entries.Count == 0)
        {
            return null;
        }

        var entry = response.Entries[0];
        var employeeId = ReadSingleAttribute(entry, activeDirectoryOptions.EmployeeIdAttribute);
        if (string.IsNullOrWhiteSpace(employeeId))
        {
            return null;
        }

        return new EncoreRoleUser
        {
            EmployeeId = employeeId,
            DisplayName = ReadSingleAttribute(entry, activeDirectoryOptions.DisplayNameAttribute) ?? employeeId,
            DistinguishedName = ReadSingleAttribute(entry, "distinguishedName") ?? distinguishedName,
            Role = mapping.Role,
            LegacyAuthorityLevel = mapping.LegacyAuthorityLevel
        };
    }

    private static string? ReadSingleAttribute(SearchResultEntry entry, string attributeName)
    {
        if (!entry.Attributes.Contains(attributeName) || entry.Attributes[attributeName].Count == 0)
        {
            return null;
        }

        return entry.Attributes[attributeName]
            .GetValues(typeof(string))
            .Cast<string>()
            .FirstOrDefault();
    }

    private static IReadOnlyList<string> ReadMultiValueAttribute(
        SearchResultEntry entry,
        string attributeName)
    {
        if (!entry.Attributes.Contains(attributeName))
        {
            return [];
        }

        return entry.Attributes[attributeName]
            .GetValues(typeof(string))
            .Cast<string>()
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .ToArray();
    }

    private static string EscapeLdapFilterValue(string value)
    {
        return value
            .Replace(@"\", @"\5c", StringComparison.Ordinal)
            .Replace("*", @"\2a", StringComparison.Ordinal)
            .Replace("(", @"\28", StringComparison.Ordinal)
            .Replace(")", @"\29", StringComparison.Ordinal)
            .Replace("\0", @"\00", StringComparison.Ordinal);
    }
}
