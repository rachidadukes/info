using Encore.Security.AspNetCore;
using LegalHoldAdmin.Components;
using LegalHoldAdmin.Data;
using LegalHoldAdmin.Services;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.EntityFrameworkCore;
using Radzen;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.ClearProviders();
builder.Logging.AddConsole();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(builder.Environment.ContentRootPath, ".keys")))
    .SetApplicationName("LegalHoldAdmin");
builder.Services.AddRadzenComponents();
builder.Services.AddHttpContextAccessor();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddEncoreSecurity(
    builder.Configuration,
    options => options.Cookie.Name = "LegalHoldAdmin.Auth");
builder.Services.AddDbContextFactory<LegalHoldDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("LegalHoldAdmin_DEV")
        ?? throw new InvalidOperationException(
            "Missing connection string: ConnectionStrings:LegalHoldAdmin_DEV")));
builder.Services.AddScoped<ILegalHoldRepository, LegalHoldRepository>();
builder.Services.AddScoped<IEJHeaderRepository, EJHeaderRepository>();
builder.Services.AddScoped<SelectedMemberState>();
builder.Services.AddHttpClient<MembersByFirstLastNameApi>((serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    var baseUrl = configuration["MemberApi:BaseUrl"]
        ?? throw new InvalidOperationException("Missing required configuration setting 'MemberApi:BaseUrl'.");

    client.BaseAddress = new Uri(baseUrl);
});
builder.Services.AddHttpClient<MembersByFullNameApi>((serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    var baseUrl = configuration["MemberApi:BaseUrl"]
        ?? throw new InvalidOperationException("Missing required configuration setting 'MemberApi:BaseUrl'.");

    client.BaseAddress = new Uri(baseUrl);
});
builder.Services.AddHttpClient<MembersBySsnApi>((serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    var baseUrl = configuration["MembersBySsnApi:BaseUrl"]
        ?? throw new InvalidOperationException("Missing required configuration setting 'MembersBySsnApi:BaseUrl'.");

    client.BaseAddress = new Uri(baseUrl);
});
builder.Services.AddHttpClient<MemberByAccessNumberApi>((serviceProvider, client) =>
{
    var configuration = serviceProvider.GetRequiredService<IConfiguration>();
    var baseUrl = configuration["MemberAccessNumberApi:BaseUrl"]
        ?? throw new InvalidOperationException("Missing required configuration setting 'MemberAccessNumberApi:BaseUrl'.");

    client.BaseAddress = new Uri(baseUrl);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
}
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();
app.MapEncoreAuthenticationEndpoints();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
