namespace LegalHoldAdmin.Models;

public sealed record PagedResult<T>(IReadOnlyList<T> Items, int TotalCount);
