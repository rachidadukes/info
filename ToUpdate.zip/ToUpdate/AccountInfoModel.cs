namespace MyApp.Domain.Entities;

public class AccountInfoModel
{
    public long    Id           { get; set; }
    public string? AcctType     { get; set; }
    public string? AcctProdCode { get; set; }
    public string? AcctProdDesc { get; set; }
}
