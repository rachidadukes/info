using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyApp.Domain.Entities;
using MyApp.ReferenceData;

namespace MyApp.Api.Controllers;

[ApiController]
[Route("api/reference")]
[Tags("LookUp Data")]
public sealed class ReferenceDataController(IReferenceDataService svc) : ControllerBase
{
    [HttpGet("access")]
    [EndpointSummary("All Access Numbers")]
    [ProducesResponseType(typeof(IReadOnlyList<AccessNumModel>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IReadOnlyList<AccessNumModel>>> GetAccess(
        [FromQuery] string? startsWith,
        [FromQuery] int take = 50,
        [FromQuery] string? apiType = null,
        [FromQuery] string? environment = null,
        CancellationToken ct = default)
        => Ok(await svc.GetAccessNumbersAsync(startsWith, take, apiType, environment, ct));

    [HttpGet("accounts")]
    [EndpointSummary("All Account Numbers")]
    [ProducesResponseType(typeof(IReadOnlyList<AccountsModel>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IReadOnlyList<AccountsModel>>> GetAccounts(
        [FromQuery] string? startsWith,
        [FromQuery] int take = 50,
        [FromQuery] string? apiType = null,
        [FromQuery] string? environment = null,
        CancellationToken ct = default)
        => Ok(await svc.GetAccountNumbersAsync(startsWith, take, apiType, environment, ct));

    [HttpGet("ssns")]
    [EndpointSummary("All SSN Numbers")]
    [ProducesResponseType(typeof(IReadOnlyList<SsnModel>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IReadOnlyList<SsnModel>>> GetSsns(
        [FromQuery] string? startsWith,
        [FromQuery] int take = 50,
        [FromQuery] string? apiType = null,
        [FromQuery] string? environment = null,
        CancellationToken ct = default)
        => Ok(await svc.GetSsnsAsync(startsWith, take, apiType, environment, ct));

    [HttpGet("membernames")]
    [EndpointSummary("All Member Names")]
    [ProducesResponseType(typeof(IReadOnlyList<MemberNameModel>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IReadOnlyList<MemberNameModel>>> GetMemberNames(
        [FromQuery] string? startsWith,
        [FromQuery] int take = 50,
        [FromQuery] string? apiType = null,
        [FromQuery] string? environment = null,
        CancellationToken ct = default)
        => Ok(await svc.GetMemberNamesAsync(startsWith, take, apiType, environment, ct));

    [HttpGet("businessnames")]
    [EndpointSummary("All Business Names")]
    [ProducesResponseType(typeof(IReadOnlyList<BusinessNameModel>), StatusCodes.Status200OK)]
    public async Task<ActionResult<IReadOnlyList<BusinessNameModel>>> GetBusinessNames(
        [FromQuery] string? startsWith,
        [FromQuery] int take = 50,
        [FromQuery] string? apiType = null,
        [FromQuery] string? environment = null,
        CancellationToken ct = default)
        => Ok(await svc.GetBusinessNamesAsync(startsWith, take, apiType, environment, ct));
}
