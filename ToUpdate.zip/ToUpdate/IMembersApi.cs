using MyApp.Contracts.DTOs;
using MyApp.Domain.Entities;

namespace MyApp.Contracts.Api
{
    /// <summary>
    /// Client contract for /api/members endpoints.
    /// </summary>
    public interface IMembersApi
    {
        // GET /api/members/{env}/profile/{accessNumber}
        Task<ResultWrapper<MemberProfileRespDTO>> GetProfileAsync(
            string selectedApiType,
            string env,
            string accessNumber,
            CancellationToken ct = default);

        // GET /api/members/{selectedApiType}/{env}/search/by-access/{accessNumber}
        Task<ResultWrapper<MemberSearchRespDTO>> SearchByAccessAsync(
            string selectedApiType,
            string env,
            string accessNumber,
            CancellationToken ct = default);

        // GET /api/members/{selectedApiType}/{env}/search/by-account?accountNumber=...&accountType=...
        Task<ResultWrapper<MemberSearchRespDTO>> SearchByAccountAsync(
            string selectedApiType,
            string env,
            string accountNumber,
            string accountType,
            CancellationToken ct = default);

        // GET /api/members/{selectedApiType}/{env}/search/by-ssn/{ssn}
        Task<ResultWrapper<MemberSearchRespDTO>> SearchBySsnAsync(
            string selectedApiType,
            string env,
            string ssn,
            CancellationToken ct = default);

        // GET /api/members/{selectedApiType}/{env}/search/by-lastname/{lastName}?firstName=...
        Task<ResultWrapper<MemberSearchRespDTO>> SearchByMemberNameAsync(
            string selectedApiType,
            string env,
            string lastName,
            string? firstName,
            CancellationToken ct = default);

        // GET /api/members/{selectedApiType}/{env}/search/by-businessname/{businessName}
        Task<ResultWrapper<MemberSearchRespDTO>> SearchByBusinessNameAsync(
            string selectedApiType,
            string env,
            string businessName,
            CancellationToken ct = default);

        // GET /api/members/history
        Task<IReadOnlyList<HistoryModel>> GetHistoryAsync(
            int take = 100,
            CancellationToken ct = default);

        // GET /api/members/history/groups
        Task<IReadOnlyList<HistoryGroupModel>> GetHistoryGroupsAsync(
            CancellationToken ct = default);

        // GET /api/members/history/by-group?description=...&environment=...
        Task<IReadOnlyList<HistoryModel>> GetHistoryByGroupAsync(
            string description,
            string environment,
            CancellationToken ct = default);

        // DELETE /api/members/history
        Task DeleteHistoryAsync(CancellationToken ct = default);

        // GET /api/members/account-info
        Task<IReadOnlyList<AccountInfoModel>> GetAccountInfoAsync(CancellationToken ct = default);

        // GET /api/members/request-type-tran-codes
        Task<IReadOnlyList<RequestTypeTranCodeModel>> GetRequestTypeTranCodesAsync(CancellationToken ct = default);
    }
}
