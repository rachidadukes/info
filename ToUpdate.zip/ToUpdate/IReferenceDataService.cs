using MyApp.Domain.Entities;

namespace MyApp.ReferenceData;

/// <summary>
/// Read-only reference data used to seed/find sample values for calls to Member APIs.
/// </summary>
public interface IReferenceDataService
{
    Task<IReadOnlyList<AccessNumModel>> GetAccessNumbersAsync(
       string? startsWith = null, int take = 50,
       string? environment = null,
       CancellationToken ct = default);

    Task<IReadOnlyList<AccountsModel>> GetAccountNumbersAsync(
       string? startsWith = null, int take = 50,
       string? environment = null,
       CancellationToken ct = default);

    Task<IReadOnlyList<SsnModel>> GetSsnsAsync(
         string? startsWith = null, int take = 50,
         string? environment = null,
         CancellationToken ct = default);

    Task<IReadOnlyList<MemberNameModel>> GetMemberNamesAsync(
        string? startsWith = null, int take = 50,
        string? environment = null,
        CancellationToken ct = default);

    Task<IReadOnlyList<BusinessNameModel>> GetBusinessNamesAsync(
        string? startsWith = null, int take = 50,
        string? environment = null,
        CancellationToken ct = default);
}
