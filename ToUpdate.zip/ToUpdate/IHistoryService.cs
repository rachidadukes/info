using MyApp.Domain.Entities;

namespace MyApp.ReferenceData;

public interface IHistoryService
{
    Task SaveAsync(HistoryModel entry, CancellationToken ct = default);
    Task<IReadOnlyList<HistoryModel>> GetAllAsync(int take = 100, CancellationToken ct = default);
    Task<IReadOnlyList<HistoryGroupModel>> GetGroupsAsync(CancellationToken ct = default);
    Task<IReadOnlyList<HistoryModel>> GetByGroupAsync(string description, string environment, CancellationToken ct = default);
    Task DeleteAllAsync(CancellationToken ct = default);
    Task<IReadOnlyList<AccountInfoModel>> GetAccountInfoAsync(CancellationToken ct = default);
}
