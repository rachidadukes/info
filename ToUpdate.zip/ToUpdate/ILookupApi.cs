using MyApp.Domain.Entities;

namespace MyApp.Contracts.Api;

public interface ILookupApi
{
    Task<List<AccessNumModel>> GetAccessNumbersAsync(
        string? environment = null, CancellationToken ct = default);

    Task<List<AccountsModel>> GetAccountNumbersAsync(
        string? environment = null, CancellationToken ct = default);

    Task<List<SsnModel>> GetSSNsAsync(
        string? environment = null, CancellationToken ct = default);

    Task<List<MemberNameModel>> GetMemberNamesAsync(
        string? environment = null, CancellationToken ct = default);

    Task<List<BusinessNameModel>> GetBusinessNamesAsync(
        string? environment = null, CancellationToken ct = default);
}
