using MyApp.Domain.Entities;

namespace MyApp.Contracts.Api;

public interface ILookupApi
{
    Task<List<AccessNumModel>> GetAccessNumbersAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default);

    Task<List<AccountsModel>> GetAccountNumbersAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default);

    Task<List<SsnModel>> GetSSNsAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default);

    Task<List<MemberNameModel>> GetMemberNamesAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default);

    Task<List<BusinessNameModel>> GetBusinessNamesAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default);
}
