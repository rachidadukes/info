using System.Net.Http.Json;
using MyApp.Contracts.Api;
using MyApp.Domain.Entities;

namespace MyApp.HttpClients.Api;

public sealed class LookupApi(HttpClient http) : ILookupApi
{
    private const string AccessPath       = "api/reference/access";
    private const string AccountsPath     = "api/reference/accounts";
    private const string SsnPath          = "api/reference/ssns";
    private const string MemberNamesPath  = "api/reference/membernames";
    private const string BusinessNamesPath = "api/reference/businessnames";

    private static string BuildUrl(string path, string? environment)
    {
        return !string.IsNullOrWhiteSpace(environment)
            ? $"{path}?environment={Uri.EscapeDataString(environment)}"
            : path;
    }

    public async Task<List<AccessNumModel>> GetAccessNumbersAsync(
        string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<AccessNumModel>>(BuildUrl(AccessPath, environment), ct) ?? new();

    public async Task<List<AccountsModel>> GetAccountNumbersAsync(
        string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<AccountsModel>>(BuildUrl(AccountsPath, environment), ct) ?? new();

    public async Task<List<SsnModel>> GetSSNsAsync(
        string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<SsnModel>>(BuildUrl(SsnPath, environment), ct) ?? new();

    public async Task<List<MemberNameModel>> GetMemberNamesAsync(
        string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<MemberNameModel>>(BuildUrl(MemberNamesPath, environment), ct) ?? new();

    public async Task<List<BusinessNameModel>> GetBusinessNamesAsync(
        string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<BusinessNameModel>>(BuildUrl(BusinessNamesPath, environment), ct) ?? new();
}
