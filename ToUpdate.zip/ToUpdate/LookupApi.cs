using System.Net.Http.Json;
using MyApp.Contracts.Api;
using MyApp.Domain.Entities;

namespace MyApp.HttpClients.Api;

public sealed class LookupApi(HttpClient http) : ILookupApi
{
    private const string AccessPath       = "api/reference/access";
    private const string AccountsPath     = "api/reference/accounts";
    private const string SsnPath          = "api/reference/ssns";
    private const string MemberNamesPath  = "api/reference/membernames";
    private const string BusinessNamesPath = "api/reference/businessnames";

    private static string BuildUrl(string path, string? apiType, string? environment)
    {
        var parts = new List<string>();
        if (!string.IsNullOrWhiteSpace(apiType))
            parts.Add($"apiType={Uri.EscapeDataString(apiType)}");
        if (!string.IsNullOrWhiteSpace(environment))
            parts.Add($"environment={Uri.EscapeDataString(environment)}");
        return parts.Count > 0 ? $"{path}?{string.Join("&", parts)}" : path;
    }

    public async Task<List<AccessNumModel>> GetAccessNumbersAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<AccessNumModel>>(BuildUrl(AccessPath, apiType, environment), ct) ?? new();

    public async Task<List<AccountsModel>> GetAccountNumbersAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<AccountsModel>>(BuildUrl(AccountsPath, apiType, environment), ct) ?? new();

    public async Task<List<SsnModel>> GetSSNsAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<SsnModel>>(BuildUrl(SsnPath, apiType, environment), ct) ?? new();

    public async Task<List<MemberNameModel>> GetMemberNamesAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<MemberNameModel>>(BuildUrl(MemberNamesPath, apiType, environment), ct) ?? new();

    public async Task<List<BusinessNameModel>> GetBusinessNamesAsync(
        string? apiType = null, string? environment = null, CancellationToken ct = default) =>
        await http.GetFromJsonAsync<List<BusinessNameModel>>(BuildUrl(BusinessNamesPath, apiType, environment), ct) ?? new();
}
