﻿
using Microsoft.EntityFrameworkCore;
using MyApp.Domain.Entities;

namespace MyApp.Infrastructure.DataAccess
{
    public class DbContextSQLite : DbContext
    {
        public DbContextSQLite(DbContextOptions<DbContextSQLite> options) : base(options) { }

        public DbSet<AccessNumModel> AccessNumbers { get; set; }
        public DbSet<AccountsModel> Accounts { get; set; }
        public DbSet<SsnModel> SSNlist { get; set; }
        public DbSet<MemberNameModel> MemberName { get; set; }

        public DbSet<BusinessNameModel> BusinessName { get; set; }
        public DbSet<HistoryModel>      History     { get; set; }
        public DbSet<AccountInfoModel>          AccountInfo            { get; set; }
        public DbSet<RequestTypeTranCodeModel>  RequestTypeTranCodes   { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AccessNumModel>(entity =>
            {
                entity.ToTable("AccessNumbers");
                entity.HasKey(e => e.Id);
            });


            modelBuilder.Entity<SsnModel>(entity =>
            {
                entity.ToTable("SSNlist");
                entity.HasKey(e => e.Id);
            });
            modelBuilder.Entity<MemberNameModel>(entity =>
            {
                entity.ToTable("MemberName");
                entity.HasKey(e => e.Id);
            });

            modelBuilder.Entity<BusinessNameModel>(entity =>
            {
                entity.ToTable("BusinessName");
                entity.HasKey(e => e.Id);
            });

            modelBuilder.Entity<HistoryModel>(entity =>
            {
                entity.ToTable("History");
                entity.HasKey(e => e.Id);
            });

            modelBuilder.Entity<AccountInfoModel>(entity =>
            {
                entity.ToTable("AccountInfo");
                entity.HasKey(e => e.Id);
            });

            modelBuilder.Entity<RequestTypeTranCodeModel>(entity =>
            {
                entity.ToTable("RequestTypeTranCodes");
                entity.HasKey(e => e.Id);
            });
        }
    }
}
