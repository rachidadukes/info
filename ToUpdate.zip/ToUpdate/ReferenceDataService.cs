using Microsoft.EntityFrameworkCore;
using MyApp.Domain.Entities;
using MyApp.Infrastructure.DataAccess;

namespace MyApp.ReferenceData;

public sealed class ReferenceDataService : IReferenceDataService
{
    private readonly IDbContextFactory<DbContextSQLite> _dbFactory;

    public ReferenceDataService(IDbContextFactory<DbContextSQLite> dbFactory)
    {
        _dbFactory = dbFactory;
    }

    public async Task<IReadOnlyList<AccessNumModel>> GetAccessNumbersAsync(
        string? startsWith = null, int take = 50,
        string? environment = null,
        CancellationToken ct = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(ct);

        var q = db.AccessNumbers.AsNoTracking()
            .Where(r => r.AccessNumber != null);

        if (!string.IsNullOrWhiteSpace(startsWith))
            q = q.Where(r => EF.Functions.Like(r.AccessNumber!, startsWith + "%"));
        if (!string.IsNullOrWhiteSpace(environment))
            q = q.Where(r => r.Environment == environment);

        return await q
            .GroupBy(r => new { r.AccessNumber, r.Environment })
            .Select(g => new AccessNumModel
            {
                AccessNumber = g.Key.AccessNumber!,
                Environment  = g.Key.Environment
            })
            .OrderBy(m => m.AccessNumber)
            .Take(take)
            .ToListAsync(ct);
    }

    public async Task<IReadOnlyList<AccountsModel>> GetAccountNumbersAsync(
        string? startsWith = null, int take = 50,
        string? environment = null,
        CancellationToken ct = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(ct);

        var q = db.Accounts.AsNoTracking()
            .Where(r => r.AccountNumber != null);

        if (!string.IsNullOrWhiteSpace(startsWith))
            q = q.Where(r => r.AccountNumber!.StartsWith(startsWith, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(environment))
            q = q.Where(r => r.Environment == environment);

        return await q
            .GroupBy(r => new { r.AccountNumber, r.AccountType, r.Environment })
            .Select(r => new AccountsModel
            {
                AccountNumber = r.Key.AccountNumber,
                AccountType   = r.Key.AccountType,
                Environment   = r.Key.Environment
            })
            .OrderBy(r => r.AccountNumber)
            .Take(take)
            .ToListAsync(ct);
    }

    public async Task<IReadOnlyList<SsnModel>> GetSsnsAsync(
        string? startsWith = null, int take = 50,
        string? environment = null,
        CancellationToken ct = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(ct);

        var q = db.SSNlist.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(startsWith))
            q = q.Where(r => r.SSN!.StartsWith(startsWith, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(environment))
            q = q.Where(r => r.Environment == environment);

        return await q
            .GroupBy(r => new { r.SSN, r.Environment })
            .Select(r => new SsnModel
            {
                SSN         = r.Key.SSN,
                Environment = r.Key.Environment
            })
            .OrderBy(r => r.SSN)
            .Take(take)
            .ToListAsync(ct);
    }

    public async Task<IReadOnlyList<MemberNameModel>> GetMemberNamesAsync(
        string? startsWith = null, int take = 50,
        string? environment = null,
        CancellationToken ct = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(ct);

        var q = db.MemberName.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(startsWith))
            q = q.Where(r => r.LastName!.StartsWith(startsWith, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(environment))
            q = q.Where(r => r.Environment == environment);

        return await q
            .GroupBy(r => new { r.LastName, r.FirstName, r.Environment })
            .Select(r => new MemberNameModel
            {
                LastName    = r.Key.LastName,
                FirstName   = r.Key.FirstName,
                Environment = r.Key.Environment
            })
            .OrderBy(r => r.LastName)
            .Take(take)
            .ToListAsync(ct);
    }

    public async Task<IReadOnlyList<BusinessNameModel>> GetBusinessNamesAsync(
        string? startsWith = null, int take = 50,
        string? environment = null,
        CancellationToken ct = default)
    {
        await using var db = await _dbFactory.CreateDbContextAsync(ct);

        var q = db.BusinessName.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(startsWith))
            q = q.Where(r => r.LegalName!.StartsWith(startsWith, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(environment))
            q = q.Where(r => r.Environment == environment);

        return await q
            .GroupBy(r => new { r.LegalName, r.Environment })
            .Select(r => new BusinessNameModel
            {
                LegalName   = r.Key.LegalName,
                Environment = r.Key.Environment
            })
            .OrderBy(r => r.LegalName)
            .Take(take)
            .ToListAsync(ct);
    }
}
