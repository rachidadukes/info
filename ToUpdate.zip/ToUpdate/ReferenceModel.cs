﻿namespace MyApp.Domain.Entities;

public sealed class AccessAcctNumberModel
{
    public long Id { get; set; }               
    public string AccessNumber { get; set; } = "";
    public string AccountNumber { get; set; } = "";
    public string AccountType { get; set; } = "";
    public string? Environment { get; set; }
    public string? ApiType { get; set; }
    public string? Comment { get; set; }
}
public class AccountsModel
{
    public int Id { get; set; }
    public string? Environment { get; set; }
    public string? AccountNumber { get; set; }
    public string? AccountType { get; set; }
}
public class AccessNumModel
{
    public int Id { get; set; }
    public string? Environment { get; set; }
    public string? AccessNumber { get; set; }
}
public class SsnModel
{
    public int Id { get; set; }
    public string? Environment { get; set; }
    public string? SSN { get; set; }
}

public class MemberNameModel
{
    public int Id { get; set; }
    public string? Environment { get; set; }
    public string? LastName { get; set; }
    public string? FirstName { get; set; }
}

public class BusinessNameModel
{
    public int Id { get; set; }
    public string? Environment { get; set; }
    public string? LegalName { get; set; }
}
