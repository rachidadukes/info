namespace MyApp.Domain.Entities;

public class RequestTypeTranCodeModel
{
    public long    Id          { get; set; }
    public string? RequestType { get; set; }
    public string? TranCode    { get; set; }
}
