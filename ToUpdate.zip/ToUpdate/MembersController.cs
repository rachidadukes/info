using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyApp.Application.Abstractions;
using MyApp.Contracts.Options;
using MyApp.Contracts;
using MyApp.Contracts.DTOs;
using MyApp.Domain.Entities;
using MyApp.ReferenceData;

namespace MyApp.Api.Controllers;

[ApiController]
[Route("api/members")]
[Tags("Members")]
public sealed class MembersController : ControllerBase
{
    private readonly IMemberReadService _svc;
    private readonly IHistoryService _historyService;

    public MembersController(IMemberReadService svc, IHistoryService historyService)
    {
        _svc = svc;
        _historyService = historyService;
    }

    // -------------------------------------------------------------------------
    // Profile
    // GET /api/members/{env}/profile/{accessNumber}
    // -------------------------------------------------------------------------

    [HttpGet("{selectedApiType}/{env}/profile/{accessNumber}")]
    [EndpointSummary("Member profile by access number")]
    [EndpointDescription("Returns a member profile from the selected environment (UNIT | INTG).")]
    [ProducesResponseType(typeof(ResultWrapper<MemberProfileRespDTO>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetProfile(
        string selectedApiType,
        string env,
        string accessNumber,
        CancellationToken ct)
    {
        if (!Enum.TryParse<AppEnvironment>(env, true, out _))
            return BadRequest("env must be UNIT or INTG.");
        if (string.IsNullOrWhiteSpace(accessNumber))
            return BadRequest("accessNumber is required.");

        try
        {
            var result = await _svc.GetProfileAsync(selectedApiType, env, accessNumber, ct);

            if (!result.IsSuccess)
                return StatusCode(StatusCodes.Status500InternalServerError, result);

            return Ok(result);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError,
                new ResultWrapper<MemberProfileRespDTO>
                {
                    IsSuccess = false,
                    ErrorMessage = $"Unexpected error: {ex.Message}"
                });
        }
    }

    // -------------------------------------------------------------------------
    // Search — all routes share the {selectedApiType}/{env} prefix
    // -------------------------------------------------------------------------

    // GET /api/members/{selectedApiType}/{env}/search/by-access/{accessNumber}
    [HttpGet("{selectedApiType}/{env}/search/by-access/{accessNumber}")]
    [EndpointSummary("Search by access number")]
    [EndpointDescription("Looks up member(s) by access number. selectedApiType: L = Legacy, N = New.")]
    [ProducesResponseType(typeof(ResultWrapper<MemberSearchRespDTO>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> SearchByAccess(
        string selectedApiType,
        string env,
        string accessNumber,
        CancellationToken ct)
    {
        if (!Enum.TryParse<AppEnvironment>(env, true, out _))
            return BadRequest("env must be UNIT or INTG.");
        if (string.IsNullOrWhiteSpace(accessNumber))
            return BadRequest("accessNumber is required.");

        try
        {
            var result = await _svc.GetMembersByAccessNumberAsync(selectedApiType, env, accessNumber, ct);

            if (!result.IsSuccess)
                return StatusCode(StatusCodes.Status500InternalServerError, result);

            return Ok(result);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError,
                new ResultWrapper<MemberSearchRespDTO>
                {
                    IsSuccess = false,
                    ErrorMessage = $"Unexpected error: {ex.Message}"
                });
        }
    }

    // GET /api/members/{selectedApiType}/{env}/search/by-account?accountNumber=...&accountType=...
    [HttpGet("{selectedApiType}/{env}/search/by-account")]
    [EndpointSummary("Search by account number")]
    [EndpointDescription("Looks up member(s) by account number and type. selectedApiType: L = Legacy, N = New.")]
    [ProducesResponseType(typeof(ResultWrapper<MemberSearchRespDTO>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> SearchByAccount(
        string selectedApiType,
        string env,
        [FromQuery] string accountNumber,
        [FromQuery] string accountType,
        CancellationToken ct)
    {
        if (!Enum.TryParse<AppEnvironment>(env, true, out _))
            return BadRequest("env must be UNIT or INTG.");
        if (string.IsNullOrWhiteSpace(accountNumber))
            return BadRequest("accountNumber is required.");
        if (string.IsNullOrWhiteSpace(accountType))
            return BadRequest("accountType is required.");

        try
        {
            var result = await _svc.GetMembersByAccountNumAsync(selectedApiType, env, accountNumber, accountType, ct);

            if (!result.IsSuccess)
                return StatusCode(StatusCodes.Status500InternalServerError, result);

            return Ok(result);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError,
                new ResultWrapper<MemberSearchRespDTO>
                {
                    IsSuccess = false,
                    ErrorMessage = $"Unexpected error: {ex.Message}"
                });
        }
    }

    // GET /api/members/{selectedApiType}/{env}/search/by-ssn/{ssn}
    [HttpGet("{selectedApiType}/{env}/search/by-ssn/{ssn}")]
    [EndpointSummary("Search by SSN")]
    [EndpointDescription("Looks up member(s) by Social Security Number. selectedApiType: L = Legacy, N = New.")]
    [ProducesResponseType(typeof(ResultWrapper<MemberSearchRespDTO>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> SearchBySsn(
        string selectedApiType,
        string env,
        string ssn,
        CancellationToken ct)
    {
        if (!Enum.TryParse<AppEnvironment>(env, true, out _))
            return BadRequest("env must be UNIT or INTG.");
        if (string.IsNullOrWhiteSpace(ssn))
            return BadRequest("ssn is required.");

        try
        {
            var result = await _svc.GetMembersBySSNAsync(selectedApiType, env, ssn, ct);

            if (!result.IsSuccess)
                return StatusCode(StatusCodes.Status500InternalServerError, result);

            return Ok(result);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError,
                new ResultWrapper<MemberSearchRespDTO>
                {
                    IsSuccess = false,
                    ErrorMessage = $"Unexpected error: {ex.Message}"
                });
        }
    }

    // GET /api/members/{selectedApiType}/{env}/search/by-lastname/{lastName}?firstName=...
    [HttpGet("{selectedApiType}/{env}/search/by-lastname/{lastName}")]
    [EndpointSummary("Search by last name")]
    [EndpointDescription("Returns member(s) matching the provided last name. selectedApiType: L = Legacy, N = New.")]
    [ProducesResponseType(typeof(ResultWrapper<MemberSearchRespDTO>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> SearchByMemberName(
        string selectedApiType,
        string env,
        string lastName,
        [FromQuery] string? firstName,
        CancellationToken ct)
    {
        if (!Enum.TryParse<AppEnvironment>(env, true, out _))
            return BadRequest("env must be UNIT or INTG.");
        if (string.IsNullOrWhiteSpace(lastName))
            return BadRequest("lastName is required.");

        try
        {
            var result = await _svc.GetMembersByNameAsync(selectedApiType, env, lastName, firstName, ct);

            if (!result.IsSuccess)
                return StatusCode(StatusCodes.Status500InternalServerError, result);

            return Ok(result);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            return StatusCode(StatusCodes.Status499ClientClosedRequest);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError,
                new ResultWrapper<MemberSearchRespDTO>
                {
                    IsSuccess = false,
                    ErrorMessage = $"Unexpected error: {ex.Message}"
                });
        }
    }

    // GET /api/members/history
    [HttpGet("history")]
    [EndpointSummary("Get search history")]
    [EndpointDescription("Returns the most recent search history records.")]
    [ProducesResponseType(typeof(IReadOnlyList<HistoryModel>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetHistory(
        [FromQuery] int take = 100,
        CancellationToken ct = default)
    {
        var result = await _historyService.GetAllAsync(take, ct);
        return Ok(result);
    }

    // GET /api/members/history/groups
    [HttpGet("history/groups")]
    [EndpointSummary("Get history grouped by description and environment")]
    [ProducesResponseType(typeof(IReadOnlyList<HistoryGroupModel>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetHistoryGroups(CancellationToken ct = default)
    {
        var result = await _historyService.GetGroupsAsync(ct);
        return Ok(result);
    }

    // GET /api/members/history/by-group?description=...&environment=...
    [HttpGet("history/by-group")]
    [EndpointSummary("Get history records for a specific group")]
    [ProducesResponseType(typeof(IReadOnlyList<HistoryModel>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetHistoryByGroup(
        [FromQuery] string description,
        [FromQuery] string environment,
        CancellationToken ct = default)
    {
        var result = await _historyService.GetByGroupAsync(description, environment, ct);
        return Ok(result);
    }

    // GET /api/members/account-info
    [HttpGet("account-info")]
    [EndpointSummary("Get all account info records")]
    [ProducesResponseType(typeof(IReadOnlyList<AccountInfoModel>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAccountInfo(CancellationToken ct = default)
    {
        var result = await _historyService.GetAccountInfoAsync(ct);
        return Ok(result);
    }

    // DELETE /api/members/history
    [HttpDelete("history")]
    [EndpointSummary("Delete all history records")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteAllHistory(CancellationToken ct = default)
    {
        await _historyService.DeleteAllAsync(ct);
        return NoContent();
    }

    // GET /api/members/{selectedApiType}/{env}/search/by-businessname/{businessName}
    [HttpGet("{selectedApiType}/{env}/search/by-businessname/{businessName}")]
    [EndpointSummary("Search by business name")]
    [EndpointDescription("Returns member(s) matching the provided business name. selectedApiType: L = Legacy, N = New.")]
    [ProducesResponseType(typeof(ResultWrapper<MemberSearchRespDTO>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> SearchByBusinessName(
        string selectedApiType,
        string env,
        string businessName,
        CancellationToken ct)
    {
        if (!Enum.TryParse<AppEnvironment>(env, true, out _))
            return BadRequest("env must be UNIT or INTG.");
        if (string.IsNullOrWhiteSpace(businessName))
            return BadRequest("businessName is required.");

        try
        {
            var result = await _svc.GetMembersByBusinessNameAsync(selectedApiType, env, businessName, ct);

            if (!result.IsSuccess)
                return StatusCode(StatusCodes.Status500InternalServerError, result);

            return Ok(result);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            return StatusCode(StatusCodes.Status499ClientClosedRequest);
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status500InternalServerError,
                new ResultWrapper<MemberSearchRespDTO>
                {
                    IsSuccess = false,
                    ErrorMessage = $"Unexpected error: {ex.Message}"
                });
        }
    }
}
