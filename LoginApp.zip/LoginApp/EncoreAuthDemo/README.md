# Encore Auth Demo

Standalone .NET 9 Blazor proof of concept for the legacy Encore authentication and authorization model.

## Purpose

The app demonstrates:

- Employee ID and network password login.
- Active Directory authentication through LDAP.
- Active Directory group membership retrieval.
- Encore group to role mapping.
- ClaimsPrincipal creation.
- Blazor authentication state.
- Role-protected pages for Admin, Supervisor, and Teller.
- A diagnostic security profile page that shows mapped demo metadata.

## Project Shape

- `Encore.Security.Core` is the single reusable security class library. It contains authentication contracts, user models, authorization roles, policies, group mapping, Active Directory LDAP integration, claims creation, cookie and policy registration, and login/logout endpoints.
- `Security.LocalTesting` is an optional development/testing class library. It replaces the real authentication service with local configured test users while reusing the same Core contracts and role mapping.
- `EncoreAuthDemo` is the Blazor host and owns environment configuration, data-protection storage, and UI.
- `Components/Pages/Authentication/` contains the login, access-denied, and security-profile pages.

The Blazor pages remain in the host so each consuming application can control its own presentation. `Encore.Security.Core` can be referenced directly or packaged as a private NuGet package for use by separate .NET 9 solutions. Apps that want local fake users for development can also reference `Security.LocalTesting`.

## Host Integration

Reference `Encore.Security.Core`, then register and map the shared functionality:

```csharp
builder.Services.AddEncoreSecurity(
    builder.Configuration,
    options => options.Cookie.Name = "YourApplication.Auth");

app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();
app.MapEncoreAuthenticationEndpoints();
```

Each host supplies its own `ActiveDirectory` configuration section. `Encore.Security.Core` includes the default Encore group mappings, and hosts only need an `EncoreAuthorization` section if they want to override those defaults.

For local development without Active Directory, reference `Security.LocalTesting`, set `SecurityProvider` to `Local`, and configure `LocalAuthentication` users whose groups match the configured Encore group mappings. The demo includes three local users in `appsettings.Development.json`:

- Admin: employee ID `1001`, password `password`
- Supervisor: employee ID `1002`, password `password`
- Teller: employee ID `1003`, password `password`

## Configuration

Set these values in `appsettings.json`, user secrets, or environment variables before testing against Active Directory:

- `ActiveDirectory:Server`
- `ActiveDirectory:Port`
- `ActiveDirectory:UseSsl`
- `ActiveDirectory:Domain`
- `ActiveDirectory:BindUserNameFormat`
- `ActiveDirectory:SearchBaseDn`

The security library includes these default group mappings:

- `BERCHA_Encore_Admin_Test` -> Admin, AuthorityLevel 1
- `BERCHA_Encore_Super_Test` -> Supervisor, AuthorityLevel 4
- `BERCHA_Encore_Teller_Test` -> Teller, AuthorityLevel 5

The app uses the mapping order as precedence when a user belongs to more than one recognized Encore group. Add `EncoreAuthorization:GroupMappings` in host configuration only when the default mappings need to be replaced.

## Running

```powershell
dotnet build EncoreAuthDemo.slnx
dotnet run --project EncoreAuthDemo\AuthDemo.csproj --launch-profile https
```

If the local HTTPS developer certificate is missing, create one with:

```powershell
dotnet dev-certs https --trust
```

Use HTTPS when entering a real network password.

## Security Notes

- The password is used only for the LDAP bind and is cleared from the login form model after authentication.
- Passwords are not logged, stored in a database, written to files, stored in browser storage, or retained in claims.
- Authorization is enforced on protected pages with standard ASP.NET Core role checks.
- `AuthorityLevel` is retained only as legacy metadata in a claim and on the diagnostic page.
- Development Data Protection keys are generated under `App_Data/DataProtectionKeys`; that folder is ignored by `.gitignore`.
