# Check Encore Active Directory On A Work PC

On your work PC, the easiest thing is to check whether your Windows/domain account belongs to the Encore Active Directory groups.

Open PowerShell or Command Prompt and run:

```powershell
whoami /groups
```

Then look for these groups:

```text
BERCHA_Encore_Admin_Test
BERCHA_Encore_Super_Test
BERCHA_Encore_Teller_Test
```

If you see one, that is the Encore role your account should map to:

| AD Group | App Role |
| --- | --- |
| `BERCHA_Encore_Admin_Test` | Admin |
| `BERCHA_Encore_Super_Test` | Supervisor |
| `BERCHA_Encore_Teller_Test` | Teller |

You can also check your domain/login server:

```powershell
whoami
echo %LOGONSERVER%
```

If RSAT / Active Directory PowerShell tools are installed, this is cleaner:

```powershell
Get-ADPrincipalGroupMembership $env:USERNAME | Select-Object Name
```

Or search specifically:

```powershell
Get-ADPrincipalGroupMembership $env:USERNAME |
    Where-Object Name -like "*Encore*"
```

For the app itself, the current Encore Active Directory config points to:

```text
Server: SWADCRVNFCUDC01.nfcu.net
Domain: NFCU
SearchBaseDn: DC=NFCU,DC=NET
```

On the work PC, if you are on the corporate network/VPN and your account is in one of those groups, the real Active Directory login should work.
