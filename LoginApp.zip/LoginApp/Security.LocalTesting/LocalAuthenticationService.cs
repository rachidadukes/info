using Encore.Security.Core.Authentication;
using Encore.Security.Core.Authorization;
using Encore.Security.Core.Models;
using Microsoft.Extensions.Options;

namespace Security.LocalTesting;

public sealed class LocalAuthenticationService(
    IOptions<LocalAuthenticationOptions> options,
    IRoleMapper roleMapper) : IAuthenticationService
{
    private readonly LocalAuthenticationOptions _options = options.Value;

    public Task<AuthenticationResult> AuthenticateAsync(
        string employeeId,
        string password,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(employeeId) || string.IsNullOrWhiteSpace(password))
        {
            return Task.FromResult(AuthenticationResult.Failed(
                AuthenticationFailureCode.MissingCredentials,
                "Employee ID and password are required."));
        }

        if (_options.Users.Count == 0)
        {
            return Task.FromResult(AuthenticationResult.Failed(
                AuthenticationFailureCode.NotConfigured,
                "Local authentication users are not configured."));
        }

        var user = _options.Users.FirstOrDefault(candidate =>
            string.Equals(candidate.EmployeeId, employeeId.Trim(), StringComparison.OrdinalIgnoreCase));

        if (user is null || !string.Equals(user.Password, password, StringComparison.Ordinal))
        {
            return Task.FromResult(AuthenticationResult.Failed(
                AuthenticationFailureCode.InvalidCredentials,
                "The employee ID or password is not valid."));
        }

        var roleMatch = roleMapper.Map(user.Groups);
        if (roleMatch is null)
        {
            return Task.FromResult(AuthenticationResult.Failed(
                AuthenticationFailureCode.NoMappedRole,
                "The local test user does not belong to a mapped Encore group."));
        }

        var encoreUser = new EncoreUser
        {
            EmployeeId = user.EmployeeId,
            DisplayName = user.DisplayName,
            DistinguishedName = $"LOCAL\\{user.EmployeeId}",
            MatchedAdGroup = roleMatch.MatchedGroup,
            Role = roleMatch.Role,
            LegacyAuthorityLevel = roleMatch.LegacyAuthorityLevel,
            ActiveDirectoryGroups = user.Groups.ToArray()
        };

        return Task.FromResult(AuthenticationResult.Success(encoreUser));
    }
}
