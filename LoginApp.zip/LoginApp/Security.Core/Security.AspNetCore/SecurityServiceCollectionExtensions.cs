using Security.ActiveDirectory;
using Security.Core.Authentication;
using Security.Core.Authorization;
using Security.Core.Options;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Security.AspNetCore;

public static class SecurityServiceCollectionExtensions
{
    public static IServiceCollection AddSecurity(
        this IServiceCollection services,
        IConfiguration configuration,
        Action<CookieAuthenticationOptions>? configureCookie = null)
    {
        services.Configure<ActiveDirectoryOptions>(
            configuration.GetSection(ActiveDirectoryOptions.SectionName));
        services.Configure<SecurityAuthorizationOptions>(
            configuration.GetSection(SecurityAuthorizationOptions.SectionName));

        services.AddSingleton<IRoleMapper>(serviceProvider =>
            new SecurityRoleMapper(
                serviceProvider.GetRequiredService<IOptions<SecurityAuthorizationOptions>>().Value));
        services.AddScoped<IAuthenticationService>(serviceProvider =>
            new ActiveDirectoryAuthenticationService(
                serviceProvider.GetRequiredService<IOptions<ActiveDirectoryOptions>>().Value,
                serviceProvider.GetRequiredService<IRoleMapper>(),
                serviceProvider.GetRequiredService<ILogger<ActiveDirectoryAuthenticationService>>()));

        services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
            .AddCookie(options =>
            {
                options.Cookie.HttpOnly = true;
                options.Cookie.SameSite = SameSiteMode.Strict;
                options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
                options.LoginPath = "/login";
                options.LogoutPath = "/logout";
                options.AccessDeniedPath = "/access-denied";
                options.SlidingExpiration = true;
                options.ExpireTimeSpan = TimeSpan.FromMinutes(30);
                configureCookie?.Invoke(options);
            });

        services.AddAuthorization(options =>
        {
            options.AddPolicy(SecurityPolicies.DeveloperOnly, policy => policy.RequireRole(SecurityRoles.Developer));
            options.AddPolicy(SecurityPolicies.AdminOnly, policy => policy.RequireRole(SecurityRoles.Admin));
            options.AddPolicy(SecurityPolicies.ClerkOnly, policy => policy.RequireRole(SecurityRoles.Clerk));
        });

        return services;
    }
}
