Imports System.Net
Imports System.Net.Http
Imports System.Net.Http.Headers
Imports System.IO
Imports System.Data.SQLite
Imports System.Text

Public Class Form1
    Private ReadOnly _httpClient As HttpClient
    Private ReadOnly _databasePath As String = Path.Combine(Application.StartupPath, "Requests.sqlite")
    Private ReadOnly _apiUrl As String = "https://swvdcdvencaej01.nfcu.net:8443/EncoreCore/api/MessageConverter/ConvertMessage"

    Public Sub New()
        InitializeComponent()

        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12

        _httpClient = New HttpClient() With {
            .Timeout = TimeSpan.FromSeconds(60)
        }

        LoadRequests()
    End Sub

    Private Sub LoadRequests()
        lstRequests.Items.Clear()
        txtSelectedRequest.Clear()
        lblStatus.Text = "Loading requests..."

        If Not File.Exists(_databasePath) Then
            lblStatus.Text = "Requests.sqlite was not found."
            Return
        End If

        Dim loadedCount As Integer = 0

        Try
            Using connection As New SQLiteConnection(String.Format("Data Source={0};Version=3;", _databasePath))
                connection.Open()

                Const sql As String = "SELECT ID, Description, Request FROM Requests ORDER BY ID"

                Using command As New SQLiteCommand(sql, connection)
                    Using reader = command.ExecuteReader()
                        While reader.Read()
                            Dim requestItem = New RequestListItem(
                                reader.GetInt32(0),
                                If(reader.IsDBNull(1), String.Empty, reader.GetString(1)),
                                If(reader.IsDBNull(2), String.Empty, reader.GetString(2))
                            )

                            lstRequests.Items.Add(requestItem)
                            loadedCount += 1
                        End While
                    End Using
                End Using
            End Using

            lblStatus.Text = String.Format("Loaded {0} request(s).", loadedCount)

            If lstRequests.Items.Count > 0 Then
                lstRequests.SelectedIndex = 0
            End If
        Catch ex As Exception
            lblStatus.Text = "Failed to load requests."
            MessageBox.Show(ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub lstRequests_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstRequests.SelectedIndexChanged
        Dim selectedItem = TryCast(lstRequests.SelectedItem, RequestListItem)

        If selectedItem Is Nothing Then
            txtSelectedRequest.Clear()
            Return
        End If

        txtSelectedRequest.Text = selectedItem.RequestBody
    End Sub

    Private Async Sub btnSend_Click(sender As Object, e As EventArgs) Handles btnSend.Click
        If String.IsNullOrWhiteSpace(txtSelectedRequest.Text) Then
            MessageBox.Show("Select a request before calling the API.", "No Request Selected", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        btnSend.Enabled = False
        lblStatus.Text = "Sending request..."

        Try
            Using request As New HttpRequestMessage(HttpMethod.Post, _apiUrl)
                Dim xmlContent = New StringContent(txtSelectedRequest.Text, Encoding.UTF8, "application/xml")
                xmlContent.Headers.ContentType = New MediaTypeHeaderValue("application/xml")
                request.Headers.Accept.Clear()
                request.Headers.Accept.Add(New MediaTypeWithQualityHeaderValue("application/xml"))
                request.Content = xmlContent

                Using response = Await _httpClient.SendAsync(request)
                    Dim responseBody = Await response.Content.ReadAsStringAsync()
                    lblStatus.Text = String.Format("Completed: {0} {1}", CInt(response.StatusCode), response.ReasonPhrase)
                    ShowResponse(responseBody, response.IsSuccessStatusCode)
                End Using
            End Using
        Catch ex As Exception
            lblStatus.Text = "Request failed"
            ShowResponse(ex.ToString(), False)
        Finally
            btnSend.Enabled = True
        End Try
    End Sub

    Private Sub ShowResponse(responseText As String, isSuccess As Boolean)
        txtResponse.Text = responseText
        tbMain.SelectedTab = tpResponse

        If isSuccess Then
            MessageBox.Show("The API call completed. Check the Response tab for details.", "API Call Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("The API call failed. Check the Response tab for details.", "API Call Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Class RequestListItem
        Public Sub New(id As Integer, description As String, requestBody As String)
            Me.Id = id
            Me.Description = description
            Me.RequestBody = requestBody
        End Sub

        Public ReadOnly Property Id As Integer
        Public ReadOnly Property Description As String
        Public ReadOnly Property RequestBody As String

        Public Overrides Function ToString() As String
            If String.IsNullOrWhiteSpace(Description) Then
                Return String.Format("Request {0}", Id)
            End If

            Return String.Format("{0} - {1}", Id, Description)
        End Function
    End Class
End Class
