<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.tbMain = New System.Windows.Forms.TabControl()
        Me.tpRequests = New System.Windows.Forms.TabPage()
        Me.lblSelectedRequest = New System.Windows.Forms.Label()
        Me.txtSelectedRequest = New System.Windows.Forms.TextBox()
        Me.lstRequests = New System.Windows.Forms.ListBox()
        Me.lblRequests = New System.Windows.Forms.Label()
        Me.btnSend = New System.Windows.Forms.Button()
        Me.tpResponse = New System.Windows.Forms.TabPage()
        Me.txtResponse = New System.Windows.Forms.TextBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.tbMain.SuspendLayout()
        Me.tpRequests.SuspendLayout()
        Me.tpResponse.SuspendLayout()
        Me.SuspendLayout()
        '
        'tbMain
        '
        Me.tbMain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbMain.Controls.Add(Me.tpRequests)
        Me.tbMain.Controls.Add(Me.tpResponse)
        Me.tbMain.Location = New System.Drawing.Point(12, 12)
        Me.tbMain.Name = "tbMain"
        Me.tbMain.SelectedIndex = 0
        Me.tbMain.Size = New System.Drawing.Size(990, 592)
        Me.tbMain.TabIndex = 0
        '
        'tpRequests
        '
        Me.tpRequests.Controls.Add(Me.lblSelectedRequest)
        Me.tpRequests.Controls.Add(Me.txtSelectedRequest)
        Me.tpRequests.Controls.Add(Me.lstRequests)
        Me.tpRequests.Controls.Add(Me.lblRequests)
        Me.tpRequests.Controls.Add(Me.btnSend)
        Me.tpRequests.Location = New System.Drawing.Point(4, 22)
        Me.tpRequests.Name = "tpRequests"
        Me.tpRequests.Padding = New System.Windows.Forms.Padding(3)
        Me.tpRequests.Size = New System.Drawing.Size(982, 566)
        Me.tpRequests.TabIndex = 0
        Me.tpRequests.Text = "Requests"
        Me.tpRequests.UseVisualStyleBackColor = True
        '
        'lblSelectedRequest
        '
        Me.lblSelectedRequest.AutoSize = True
        Me.lblSelectedRequest.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lblSelectedRequest.Location = New System.Drawing.Point(53, 262)
        Me.lblSelectedRequest.Name = "lblSelectedRequest"
        Me.lblSelectedRequest.Size = New System.Drawing.Size(145, 21)
        Me.lblSelectedRequest.TabIndex = 4
        Me.lblSelectedRequest.Text = "Selected Request"
        '
        'txtSelectedRequest
        '
        Me.txtSelectedRequest.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSelectedRequest.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtSelectedRequest.Location = New System.Drawing.Point(57, 294)
        Me.txtSelectedRequest.Multiline = True
        Me.txtSelectedRequest.Name = "txtSelectedRequest"
        Me.txtSelectedRequest.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtSelectedRequest.Size = New System.Drawing.Size(883, 132)
        Me.txtSelectedRequest.TabIndex = 3
        '
        'lstRequests
        '
        Me.lstRequests.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstRequests.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.lstRequests.FormattingEnabled = True
        Me.lstRequests.ItemHeight = 20
        Me.lstRequests.Location = New System.Drawing.Point(57, 93)
        Me.lstRequests.Name = "lstRequests"
        Me.lstRequests.Size = New System.Drawing.Size(883, 124)
        Me.lstRequests.TabIndex = 1
        '
        'lblRequests
        '
        Me.lblRequests.AutoSize = True
        Me.lblRequests.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lblRequests.Location = New System.Drawing.Point(40, 47)
        Me.lblRequests.Name = "lblRequests"
        Me.lblRequests.Size = New System.Drawing.Size(80, 21)
        Me.lblRequests.TabIndex = 0
        Me.lblRequests.Text = "Requests"
        '
        'btnSend
        '
        Me.btnSend.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnSend.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(145, Byte), Integer), CType(CType(232, Byte), Integer))
        Me.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSend.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnSend.ForeColor = System.Drawing.Color.White
        Me.btnSend.Location = New System.Drawing.Point(309, 468)
        Me.btnSend.Name = "btnSend"
        Me.btnSend.Size = New System.Drawing.Size(365, 44)
        Me.btnSend.TabIndex = 2
        Me.btnSend.Text = "Call API"
        Me.btnSend.UseVisualStyleBackColor = False
        '
        'tpResponse
        '
        Me.tpResponse.Controls.Add(Me.txtResponse)
        Me.tpResponse.Location = New System.Drawing.Point(4, 22)
        Me.tpResponse.Name = "tpResponse"
        Me.tpResponse.Padding = New System.Windows.Forms.Padding(3)
        Me.tpResponse.Size = New System.Drawing.Size(982, 566)
        Me.tpResponse.TabIndex = 1
        Me.tpResponse.Text = "Response"
        Me.tpResponse.UseVisualStyleBackColor = True
        '
        'txtResponse
        '
        Me.txtResponse.AcceptsReturn = True
        Me.txtResponse.AcceptsTab = True
        Me.txtResponse.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtResponse.Font = New System.Drawing.Font("Consolas", 10.0!)
        Me.txtResponse.Location = New System.Drawing.Point(18, 18)
        Me.txtResponse.Multiline = True
        Me.txtResponse.Name = "txtResponse"
        Me.txtResponse.ReadOnly = True
        Me.txtResponse.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtResponse.Size = New System.Drawing.Size(946, 530)
        Me.txtResponse.TabIndex = 0
        Me.txtResponse.WordWrap = False
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New System.Drawing.Point(12, 611)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(24, 13)
        Me.lblStatus.TabIndex = 1
        Me.lblStatus.Text = "Idle"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1014, 633)
        Me.Controls.Add(Me.tbMain)
        Me.Controls.Add(Me.lblStatus)
        Me.MinimumSize = New System.Drawing.Size(900, 600)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ApiTester"
        Me.tbMain.ResumeLayout(False)
        Me.tpRequests.ResumeLayout(False)
        Me.tpRequests.PerformLayout()
        Me.tpResponse.ResumeLayout(False)
        Me.tpResponse.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tbMain As TabControl
    Friend WithEvents tpRequests As TabPage
    Friend WithEvents lblSelectedRequest As Label
    Friend WithEvents txtSelectedRequest As TextBox
    Friend WithEvents lstRequests As ListBox
    Friend WithEvents lblRequests As Label
    Friend WithEvents btnSend As Button
    Friend WithEvents tpResponse As TabPage
    Friend WithEvents txtResponse As TextBox
    Friend WithEvents lblStatus As Label
End Class
