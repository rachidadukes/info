using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace MyApp.Integrations.Helpers
{
    public static class ObjectToXmlSerializer
    {
        public static string ToXmlString<T>(T value)
        {
            if (value == null)
                return string.Empty;

            var serializer = new XmlSerializer(typeof(T));

            var settings = new XmlWriterSettings
            {
                Indent = true,
                OmitXmlDeclaration = false,
                Encoding = new UTF8Encoding(false)
            };

            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty); // removes xmlns:xsi / xmlns:xsd

            using var stringWriter = new Utf8StringWriter();
            using var xmlWriter = XmlWriter.Create(stringWriter, settings);

            serializer.Serialize(xmlWriter, value, namespaces);

            return stringWriter.ToString();
        }

        private sealed class Utf8StringWriter : StringWriter
        {
            public override Encoding Encoding => new UTF8Encoding(false);
        }
    }
}
