namespace MyApp.Integrations.Helpers
{
    public static class TypeValues
    {
        public static class Endpoint
        {
            public const string LegacyEndpoint = "L";
            public const string NewEndpoint    = "N";
        }

        public static class MemberSearchType
        {
            public const string MemberSearchAccessNumber = "MemberSearchAccessNumber";
            public const string MemberSearchAccount      = "MemberSearchAccount";
            public const string MemberSearchLastName     = "MemberSearchLastName";
            public const string MemberSearchSSN          = "MemberSearchSSN";
            public const string MemberSearchBusiness     = "MemberSearchBusiness";
        }

        public static class Type
        {
            public const string CD_Deposit     = "CD_Deposit";
            public const string IRA_CD_Deposit = "IRA_CD_Deposit";
            public const string MemberProfile  = "MemberProfile";
            public const string MemberSearch   = "MemberSearch";
        }
    }
}
