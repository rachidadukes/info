using System.Text.RegularExpressions;

namespace MyApp.Integrations.Helpers
{
    public static class XmlNamespaceHelper
    {
        public static string AddMissingNamespaces(string xml)
        {
            string errorXml = string.Empty;

            try
            {
                const string ns = "http://schemas.navyfederal.org/2010/04/NFBranchExService";

                xml = AddNamespacToTag(xml, "MsgRqHdr",        ns);
                xml = AddNamespacToTag(xml, "SearchMemberInfo", ns);
                return xml;
            }
            catch (Exception ex)
            {
                errorXml = "===== UNEXPECTED ERROR =====" + ex;
                return errorXml;
            }
        }

        private static string AddNamespacToTag(string xml, string tagName, string namespaceValue)
        {
            string pattern = $@"<{tagName}(?![^>]*\bxmlns=)([^>]*)>";
            return Regex.Replace(
                xml,
                pattern,
                $"<{tagName} xmlns=\"{namespaceValue}\"$1>");
        }
    }
}
