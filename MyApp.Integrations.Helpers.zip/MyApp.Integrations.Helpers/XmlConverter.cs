using System.Xml.Serialization;

namespace MyApp.Integrations.Helpers
{
    public static class XmlConverter
    {
        public static T Deserialize<T>(string xml)
        {
            var serializer = new XmlSerializer(typeof(T));

            using var reader = new StringReader(xml);
            return (T)serializer.Deserialize(reader)!;
        }
    }
}
