namespace LegalHoldAdmin.Services;

public sealed class SelectedMemberState
{
    public string? AccessNumber { get; private set; }
    public string? DisplayName { get; private set; }

    public bool HasSelectedMember => !string.IsNullOrWhiteSpace(AccessNumber);

    public event Action? OnChange;

    public void SelectMember(string? accessNumber, string? displayName)
    {
        AccessNumber = string.IsNullOrWhiteSpace(accessNumber) ? null : accessNumber.Trim();
        DisplayName = string.IsNullOrWhiteSpace(displayName) ? null : displayName.Trim();

        OnChange?.Invoke();
    }

    public void Clear()
    {
        AccessNumber = null;
        DisplayName = null;

        OnChange?.Invoke();
    }
}
