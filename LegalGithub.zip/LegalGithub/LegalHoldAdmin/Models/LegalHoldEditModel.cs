using System.ComponentModel.DataAnnotations;

namespace LegalHoldAdmin.Models;

public sealed class LegalHoldEditModel
{
    public int? ID { get; set; }

    [Required]
    [StringLength(30)]
    public string? AccessNumber { get; set; }

    [Required]
    [StringLength(30)]
    public string? Name { get; set; }

    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public bool Active { get; set; } = true;

    public bool IsInsert => !ID.HasValue || ID.Value <= 0;

    public static LegalHoldEditModel FromResult(LegalHoldResult item) => new()
    {
        ID = item.ID,
        AccessNumber = item.AccessNumber,
        Name = item.LegalHoldName,
        StartDate = item.StartDate,
        EndDate = item.EndDate,
        Active = item.Active
    };
}
