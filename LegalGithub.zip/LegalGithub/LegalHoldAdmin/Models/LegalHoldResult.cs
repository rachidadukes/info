namespace LegalHoldAdmin.Models;

public sealed class LegalHoldResult
{
    public int? ID { get; set; }
    public int? CustomerID { get; set; }
    public string? LegalHoldName { get; set; }
    public string? FirstName { get; set; }
    public string? MiddleName { get; set; }
    public string? LastName { get; set; }
    public string? AccessNumber { get; set; }
    public string? AccountNumber { get; set; }
    public string? SocialSecurityNumber { get; set; }
    public DateTime? StartDate { get; set; }
    public DateTime? EndDate { get; set; }
    public bool Active { get; set; } = true;
    public DateTime? DateCreated { get; set; }
    public string? UserInserted { get; set; }

    public string CustomerName => string.Join(" ",
        new[]
        {
            FirstName, MiddleName, LastName
        }
        .Where(x => !string.IsNullOrWhiteSpace(x)));
}
