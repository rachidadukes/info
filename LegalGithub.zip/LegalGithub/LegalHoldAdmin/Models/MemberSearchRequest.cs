using System.Text.Json.Serialization;

namespace LegalHoldAdmin.Models;

public sealed class MemberSearchRequest
{
    [JsonPropertyName("NFCURequestHeader")]
    public required NfcuRequestHeader NFCURequestHeader { get; init; }

    [JsonPropertyName("ssn")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Ssn { get; init; }

    [JsonPropertyName("accessNumber")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? AccessNumber { get; init; }

    [JsonPropertyName("fullName")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? FullName { get; init; }

    [JsonPropertyName("firstName")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? FirstName { get; init; }

    [JsonPropertyName("lastName")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? LastName { get; init; }

    [JsonPropertyName("membershipType")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? MembershipType { get; init; }

    [JsonPropertyName("activeStatusIndicator")]
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? ActiveStatusIndicator { get; init; }
}

public sealed class NfcuRequestHeader
{
    [JsonPropertyName("credential")]
    public required string Credential { get; init; }

    [JsonPropertyName("rqUID")]
    public required string RqUID { get; init; }

    [JsonPropertyName("consumerChannel")]
    public required string ConsumerChannel { get; init; }

    [JsonPropertyName("consumingApplicationName")]
    public required string ConsumingApplicationName { get; init; }
}
