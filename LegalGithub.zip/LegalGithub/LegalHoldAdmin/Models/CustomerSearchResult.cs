namespace LegalHoldAdmin.Models;

public sealed class CustomerSearchResult
{
    public int CustomerID { get; set; }
    public string? FirstName { get; set; }
    public string? MiddleName { get; set; }
    public string? LastName { get; set; }
    public string? AccessNumber { get; set; }
    public string? AccountNumber { get; set; }
    public string? SocialSecurityNumber { get; set; }

    public string CustomerName =>
        string.Join(" ",
            new[] { FirstName, MiddleName, LastName }
                .Where(x => !string.IsNullOrWhiteSpace(x)));
}
