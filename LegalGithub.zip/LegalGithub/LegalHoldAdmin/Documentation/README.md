# LegalHoldAdmin

This project was reconstructed from screenshots of the original Visual Studio solution.

Known structure from the screenshots:

- ASP.NET Core Blazor Web App
- Target framework: `net9.0`
- Packages:
  - `Microsoft.Data.SqlClient` `7.0.2`
  - `Radzen.Blazor` `11.2.8`
- Visible folders/pages:
  - `Components/Layout/MainLayout.razor`
  - `Components/Pages/Home.razor`
  - `Components/Pages/LegalHolds.razor`
  - `Components/Pages/LegalHoldsOld.razor`
  - `Components/CustomerSearch.razor`
  - `Components/CustomerSearchOld.razor`
  - `Components/LegalHoldSearch.razor`
  - `Components/LegalHoldSearchOld.razor`
  - `Data/ILegalHoldRepository.cs`
  - `Data/LegalHoldRepository.cs`
  - `Models/CustomerSearchResult.cs`
  - `Models/LegalHoldEditModel.cs`
  - `Models/LegalHoldResult.cs`
  - `Models/LegalHoldSearchRequest.cs`

Configuration captured from screenshots:

- `ConnectionStrings:LegalHoldAdmin_DEV`
- `LegalHold:ReadonlyMode`
- `LegalHold:SearchLegalHoldProcedure` = `dbo.Search_EJLegalHold`
- `LegalHold:SearchCustomerProcedure` = `dbo.Search_EJLegalHold_Customers`
- `LegalHold:InsertUpdateProcedure` = `dbo.INS_UPD_EJLegalHold`

The current implementation uses sample in-memory data so the app can run locally.
When database details are available, replace `Data/LegalHoldRepository.cs` with SQL-backed queries using `Microsoft.Data.SqlClient`.
