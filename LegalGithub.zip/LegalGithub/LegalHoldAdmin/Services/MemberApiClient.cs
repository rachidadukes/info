using System.Net.Http.Json;

namespace LegalHoldAdmin.Services;

public sealed class MemberApiClient
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;

    public MemberApiClient(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _configuration = configuration;
    }

    public async Task<string> SearchMemberAsync(string firstName, string lastName, CancellationToken cancellationToken = default)
    {
        using var request = new HttpRequestMessage(HttpMethod.Post, "member/v1/members/search");

        request.Headers.Add("x-nfcu-clientid", GetRequiredSetting("MemberApi:ClientId"));
        request.Headers.Add("x-nfcu-clientsecret", GetRequiredSetting("MemberApi:ClientSecret"));

        var body = new
        {
            NFCURequestHeader = new
            {
                credential = GetRequiredSetting("MemberApi:Credential"),
                rqUID = Guid.NewGuid().ToString(),
                consumerChannel = GetRequiredSetting("MemberApi:ConsumerChannel"),
                consumingApplicationName = GetRequiredSetting("MemberApi:ConsumingApplicationName")
            },
            membershipType = "P",
            firstName,
            lastName,
            activeStatusIndicator = "0"
        };

        request.Content = JsonContent.Create(body);

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            throw new HttpRequestException(
                $"Member API returned {(int)response.StatusCode} {response.ReasonPhrase}: {responseBody}");
        }

        return responseBody;
    }

    private string GetRequiredSetting(string key)
    {
        return _configuration[key]
            ?? throw new InvalidOperationException($"Missing required configuration setting '{key}'.");
    }
}
