from __future__ import annotations

import argparse

from emp_accts_repository import EmpAcctsRepository


DEFAULT_EMPLOYEE_ID = "37015"
DEFAULT_ENDPOINT = (
    "https://intg-dpa-lb.nfcutest.net:5508/"
    "NFCUBranchTellerServices/rest/employee-account-relationships/v1/"
    "employee/relationships/accounts"
)


def display_employee_accounts(endpoint: str, employee_id: str) -> str:
    acct_object = EmpAcctsRepository()
    host_response = acct_object.get_employee_accounts(endpoint, employee_id)

    if host_response is None:
        host_response_message = "No accounts found for this Employee"
    elif host_response.AcctsResult.Data is None:
        host_response_message = "No accounts found for this Employee"
    elif host_response.AcctsResult.IsSuccess:
        account_list = host_response.AcctsResult.Data.accounts or []
        host_response_message = (
            "Successfully retrieved accounts for this employee. "
            f"Number of accounts retrieved is : {len(account_list)}"
        )
    else:
        host_response_message = (
            "Unknown error occurred while processing the host response "
            "for this employee"
        )

    print(host_response_message)
    return host_response_message


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Retrieve employee account relationships from the host API."
    )
    parser.add_argument(
        "--employee-id",
        default=DEFAULT_EMPLOYEE_ID,
        help=f"Employee id to send to the API. Default: {DEFAULT_EMPLOYEE_ID}",
    )
    parser.add_argument(
        "--endpoint",
        default=DEFAULT_ENDPOINT,
        help="API endpoint URL.",
    )

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    display_employee_accounts(args.endpoint, args.employee_id)
