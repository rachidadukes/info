from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Account:
    RealAccountType: str | None = None
    AccountType: str | None = None
    AccountNumber: str | None = None

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "Account":
        return cls(
            RealAccountType=value.get("RealAccountType"),
            AccountType=value.get("AccountType"),
            AccountNumber=value.get("AccountNumber"),
        )


@dataclass
class ResponseHeader:
    ErrorResponse: str | None = None
    Message: str | None = None
    StatusCode: int = 0

    @classmethod
    def from_dict(cls, value: dict[str, Any] | None) -> "ResponseHeader | None":
        if value is None:
            return None

        return cls(
            ErrorResponse=value.get("ErrorResponse"),
            Message=value.get("Message"),
            StatusCode=value.get("StatusCode", 0),
        )


@dataclass
class EmpAcctsResponseModel:
    ErrorResponse: str | None = None
    btsStatusCode: str | None = None
    responseHeader: ResponseHeader | None = None
    accounts: list[Account] | None = None
    btsStatusMessage: str | None = None

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> "EmpAcctsResponseModel":
        accounts_value = value.get("accounts")
        accounts = None

        if isinstance(accounts_value, list):
            accounts = [
                Account.from_dict(account)
                for account in accounts_value
                if isinstance(account, dict)
            ]

        return cls(
            ErrorResponse=value.get("ErrorResponse"),
            btsStatusCode=value.get("btsStatusCode"),
            responseHeader=ResponseHeader.from_dict(value.get("responseHeader")),
            accounts=accounts,
            btsStatusMessage=value.get("btsStatusMessage"),
        )


@dataclass
class ResultWrapper:
    IsSuccess: bool = False
    Data: EmpAcctsResponseModel | None = None
    ErrorMessage: str | None = ""

    @classmethod
    def success(cls, data: EmpAcctsResponseModel) -> "ResultWrapper":
        return cls(IsSuccess=True, Data=data, ErrorMessage=None)

    @classmethod
    def fail(cls, error_message: str) -> "ResultWrapper":
        return cls(IsSuccess=False, Data=None, ErrorMessage=error_message)


@dataclass
class GetEmployeeAccountsResponseResult:
    Request: str | None = None
    RootResponse: str | None = None
    AcctsResult: ResultWrapper = field(default_factory=ResultWrapper)
