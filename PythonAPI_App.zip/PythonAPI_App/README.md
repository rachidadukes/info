# PythonAPI_App

Python version of the .NET 9 `APIConsoleApp`.

## Setup

```powershell
cd "C:\Users\rachi\Desktop\Learning Python\APIConsoleApp\PythonAPI_App"
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
```

## Run

```powershell
py main.py
```

Optional overrides:

```powershell
py main.py --employee-id 37015 --endpoint "https://example.com/accounts"
```
