from __future__ import annotations

import json
from uuid import uuid4

import requests

from models import EmpAcctsResponseModel, GetEmployeeAccountsResponseResult, ResultWrapper


class EmpAcctsRepository:
    def get_employee_accounts(
        self,
        endpoint: str,
        employee_id: str,
        timeout_seconds: int = 30,
    ) -> GetEmployeeAccountsResponseResult:
        json_request = {
            "rquid": str(uuid4()),
            "employeeID": employee_id,
        }
        request_body = json.dumps(json_request, indent=2)

        try:
            response = requests.post(
                endpoint,
                json=json_request,
                timeout=timeout_seconds,
            )

            if 200 <= response.status_code < 300:
                response_model = EmpAcctsResponseModel.from_dict(response.json())

                return GetEmployeeAccountsResponseResult(
                    Request=request_body,
                    RootResponse=response.text,
                    AcctsResult=ResultWrapper.success(response_model),
                )

            error_message = f"API error: {response.status_code} - {response.reason}"
            return GetEmployeeAccountsResponseResult(
                Request=request_body,
                RootResponse=response.text,
                AcctsResult=ResultWrapper.fail(error_message),
            )
        except requests.RequestException as ex:
            error_message = f"An error occurred while making the HTTP request: {ex}"
            print(error_message)

            return GetEmployeeAccountsResponseResult(
                Request=request_body,
                RootResponse=None,
                AcctsResult=ResultWrapper.fail(error_message),
            )
        except ValueError as ex:
            error_message = f"An error occurred while parsing the host response: {ex}"
            print(error_message)

            return GetEmployeeAccountsResponseResult(
                Request=request_body,
                RootResponse=None,
                AcctsResult=ResultWrapper.fail(error_message),
            )
