using Security.AspNetCore;
using Security.LocalTesting;
using EncoreAuthDemo.Components;
using Microsoft.AspNetCore.DataProtection;
using Radzen;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();
builder.Services.AddRadzenComponents();

var dataProtection = builder.Services.AddDataProtection()
    .SetApplicationName("EncoreAuthDemo");

if (builder.Environment.IsDevelopment())
{
    dataProtection.PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(
        builder.Environment.ContentRootPath,
        "App_Data",
        "DataProtectionKeys")));
}

builder.Services.AddHttpContextAccessor();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddSecurity(
    builder.Configuration,
    options => options.Cookie.Name = "EncoreAuthDemo.Auth");

if (builder.Environment.IsDevelopment() &&
    string.Equals(builder.Configuration["SecurityProvider"], "Local", StringComparison.OrdinalIgnoreCase))
{
    builder.Services.AddLocalTestingSecurity(builder.Configuration);
}

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.UseAntiforgery();
app.MapSecurityAuthenticationEndpoints();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
