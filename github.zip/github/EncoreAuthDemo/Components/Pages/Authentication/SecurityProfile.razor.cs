using System.Security.Claims;
using Security.AspNetCore;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;

namespace EncoreAuthDemo.Components.Pages.Authentication;

public partial class SecurityProfile
{
    [CascadingParameter]
    private Task<AuthenticationState> AuthenticationStateTask { get; set; } = default!;

    private ClaimsPrincipal? User { get; set; }

    private string EmployeeId => ReadClaim(SecurityClaimTypes.EmployeeId);

    private string DisplayName => ReadClaim(SecurityClaimTypes.DisplayName);

    private string MatchedAdGroup => ReadClaim(SecurityClaimTypes.MatchedAdGroup);

    private string Role => User?.FindFirst(ClaimTypes.Role)?.Value ?? string.Empty;

    private string AuthorityLevel => ReadClaim(SecurityClaimTypes.AuthorityLevel);

    protected override async Task OnInitializedAsync()
    {
        User = (await AuthenticationStateTask).User;
    }

    private string ReadClaim(string claimType)
    {
        return User?.FindFirst(claimType)?.Value ?? string.Empty;
    }
}
