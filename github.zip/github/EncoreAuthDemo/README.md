# Auth Demo

Standalone .NET 9 Blazor proof of concept for Active Directory authentication and role-based authorization.

## Purpose

The app demonstrates:

- Employee ID and network password login.
- Active Directory authentication through LDAP.
- Active Directory group membership retrieval.
- Configurable AD group to app role mapping.
- ClaimsPrincipal creation.
- Blazor authentication state.
- Role-protected pages for Developer, Admin, and Clerk.
- A diagnostic security profile page that shows mapped metadata.

## Project Shape

- `Security.Core` is the reusable security class library. It contains authentication contracts, user models, authorization roles, policies, group mapping, Active Directory LDAP integration, claims creation, cookie and policy registration, and login/logout endpoints.
- `Security.LocalTesting` is an optional development/testing class library. It replaces the real authentication service with local configured test users while reusing the same `Security.Core` contracts and role mapping.
- `AuthDemo` is the Blazor host and owns environment configuration, data-protection storage, and UI.
- `Components/Pages/Authentication/` contains the login, access-denied, and security-profile pages.

The Blazor pages remain in the host so each consuming application can control its own presentation. `Security.Core` can be referenced directly or packaged as a private NuGet package for use by separate .NET 9 solutions. Apps that want local fake users for development can also reference `Security.LocalTesting`.

## Host Integration

Reference `Security.Core`, then register and map the shared functionality:

```csharp
builder.Services.AddSecurity(
    builder.Configuration,
    options => options.Cookie.Name = "YourApplication.Auth");

app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();
app.MapSecurityAuthenticationEndpoints();
```

Each host supplies its own `ActiveDirectory` and `SecurityAuthorization` configuration sections.

For local development without Active Directory, reference `Security.LocalTesting`, set `SecurityProvider` to `Local`, and configure `LocalAuthentication` users whose groups match the configured security group mappings. The demo includes three local users in `appsettings.Development.json`:

- Developer: employee ID `1001`, password `password`
- Admin: employee ID `1002`, password `password`
- Clerk: employee ID `1003`, password `password`

## Configuration

Set these values in `appsettings.json`, user secrets, or environment variables before testing against Active Directory:

- `ActiveDirectory:Server`
- `ActiveDirectory:Port`
- `ActiveDirectory:UseSsl`
- `ActiveDirectory:Domain`
- `ActiveDirectory:BindUserNameFormat`
- `ActiveDirectory:SearchBaseDn`
- `SecurityAuthorization:GroupMappings`

Replace the placeholder group names in `SecurityAuthorization:GroupMappings` when the real Active Directory groups are known.

## Running

```powershell
dotnet build AuthDemo.slnx
dotnet run --project EncoreAuthDemo\AuthDemo.csproj --launch-profile https
```

If the local HTTPS developer certificate is missing, create one with:

```powershell
dotnet dev-certs https --trust
```

Use HTTPS when entering a real network password.

## Security Notes

- The password is used only for the LDAP bind and is cleared from the login form model after authentication.
- Passwords are not logged, stored in a database, written to files, stored in browser storage, or retained in claims.
- Authorization is enforced on protected pages with standard ASP.NET Core role checks.
- `AuthorityLevel` is retained only as metadata in a claim and on the diagnostic page.
- Development Data Protection keys are generated under `App_Data/DataProtectionKeys`; that folder is ignored by `.gitignore`.
