using Security.Core.Authentication;
using Security.Core.Groups;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Security.LocalTesting;

public static class SecurityLocalTestingServiceCollectionExtensions
{
    public static IServiceCollection AddLocalTestingSecurity(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<LocalAuthenticationOptions>(
            configuration.GetSection(LocalAuthenticationOptions.SectionName));

        services.RemoveAll<IAuthenticationService>();
        services.AddScoped<IAuthenticationService, LocalAuthenticationService>();
        services.RemoveAll<ISecurityGroupUserDirectory>();
        services.AddScoped<ISecurityGroupUserDirectory, LocalSecurityGroupUserDirectory>();

        return services;
    }
}
