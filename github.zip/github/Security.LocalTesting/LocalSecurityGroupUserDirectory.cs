using Security.Core.Groups;
using Security.Core.Options;
using Microsoft.Extensions.Options;

namespace Security.LocalTesting;

public sealed class LocalSecurityGroupUserDirectory(
    IOptions<LocalAuthenticationOptions> localOptions,
    IOptions<SecurityAuthorizationOptions> authorizationOptions) : ISecurityGroupUserDirectory
{
    public Task<SecurityGroupUsers> GetUsersForRoleAsync(
        string role,
        CancellationToken cancellationToken = default)
    {
        var mapping = authorizationOptions.Value.GroupMappings
            .OrderBy(groupMapping => groupMapping.Precedence)
            .FirstOrDefault(groupMapping =>
                string.Equals(groupMapping.Role, role, StringComparison.OrdinalIgnoreCase));

        if (mapping is null)
        {
            return Task.FromResult(new SecurityGroupUsers(role, "Not configured", []));
        }

        var users = localOptions.Value.Users
            .Where(user => user.Groups.Any(group =>
                IsMatch(group, mapping.GroupName) ||
                IsMatch(group, mapping.DistinguishedName) ||
                ContainsCommonName(group, mapping.GroupName)))
            .OrderBy(user => user.DisplayName)
            .ThenBy(user => user.EmployeeId)
            .Select(user => new SecurityGroupUser(user.EmployeeId, user.DisplayName))
            .ToArray();

        return Task.FromResult(new SecurityGroupUsers(role, mapping.GroupName, users));
    }

    private static bool IsMatch(string candidate, string configuredValue)
    {
        return !string.IsNullOrWhiteSpace(candidate) &&
            !string.IsNullOrWhiteSpace(configuredValue) &&
            string.Equals(candidate.Trim(), configuredValue.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    private static bool ContainsCommonName(string distinguishedName, string groupName)
    {
        if (string.IsNullOrWhiteSpace(distinguishedName) || string.IsNullOrWhiteSpace(groupName))
        {
            return false;
        }

        return distinguishedName.Contains($"CN={groupName}", StringComparison.OrdinalIgnoreCase);
    }
}
