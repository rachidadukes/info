namespace Security.LocalTesting;

public sealed class LocalTestUser
{
    public string EmployeeId { get; init; } = string.Empty;

    public string Password { get; init; } = string.Empty;

    public string DisplayName { get; init; } = string.Empty;

    public IReadOnlyList<string> Groups { get; init; } = [];
}
