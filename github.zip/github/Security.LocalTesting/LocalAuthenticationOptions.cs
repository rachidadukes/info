namespace Security.LocalTesting;

public sealed class LocalAuthenticationOptions
{
    public const string SectionName = "LocalAuthentication";

    public IReadOnlyList<LocalTestUser> Users { get; init; } = [];
}
