namespace Security.Core.Groups;

public sealed class UnavailableSecurityGroupUserDirectory : ISecurityGroupUserDirectory
{
    public Task<SecurityGroupUsers> GetUsersForRoleAsync(
        string role,
        CancellationToken cancellationToken = default)
    {
        return Task.FromResult(new SecurityGroupUsers(role, "Not configured", []));
    }
}
