namespace Security.Core.Groups;

public interface ISecurityGroupUserDirectory
{
    Task<SecurityGroupUsers> GetUsersForRoleAsync(
        string role,
        CancellationToken cancellationToken = default);
}
