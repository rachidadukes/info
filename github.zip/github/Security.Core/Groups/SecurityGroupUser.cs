namespace Security.Core.Groups;

public sealed record SecurityGroupUser(
    string EmployeeId,
    string DisplayName);
