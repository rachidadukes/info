namespace Security.Core.Groups;

public sealed record SecurityGroupUsers(
    string Role,
    string GroupName,
    IReadOnlyList<SecurityGroupUser> Users);
