# Security.Core

Reusable .NET 9 security class library for Active Directory authentication and role mapping.

## Roles

The library defines these application roles:

- `Developer`
- `Admin`
- `Clerk`

## Configuration

The real Active Directory group names are supplied by the host application, not hard-coded in this library. Replace the placeholder group names and distinguished names when the real AD groups are known.

```json
{
  "ActiveDirectory": {
    "Server": "your-domain-controller.example.com",
    "Port": 389,
    "UseSsl": false,
    "Domain": "YOURDOMAIN",
    "BindUserNameFormat": "{employeeId}",
    "SearchBaseDn": "DC=example,DC=com",
    "EmployeeIdAttribute": "sAMAccountName",
    "DisplayNameAttribute": "displayName",
    "GroupMembershipAttribute": "memberOf",
    "AuthType": "Negotiate"
  },
  "SecurityAuthorization": {
    "GroupMappings": [
      {
        "GroupName": "TODO_Developer_AD_Group",
        "DistinguishedName": "CN=TODO_Developer_AD_Group,OU=Groups,DC=example,DC=com",
        "Role": "Developer",
        "AuthorityLevel": 1,
        "Precedence": 1
      },
      {
        "GroupName": "TODO_Admin_AD_Group",
        "DistinguishedName": "CN=TODO_Admin_AD_Group,OU=Groups,DC=example,DC=com",
        "Role": "Admin",
        "AuthorityLevel": 2,
        "Precedence": 2
      },
      {
        "GroupName": "TODO_Clerk_AD_Group",
        "DistinguishedName": "CN=TODO_Clerk_AD_Group,OU=Groups,DC=example,DC=com",
        "Role": "Clerk",
        "AuthorityLevel": 3,
        "Precedence": 3
      }
    ]
  }
}
```

## Host Usage

```csharp
using Security.AspNetCore;

builder.Services.AddSecurity(builder.Configuration);

app.UseAuthentication();
app.UseAuthorization();
app.MapSecurityAuthenticationEndpoints();
```
