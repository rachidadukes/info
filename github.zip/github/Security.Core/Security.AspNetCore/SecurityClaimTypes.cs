namespace Security.AspNetCore;

public static class SecurityClaimTypes
{
    public const string EmployeeId = "security:employee_id";
    public const string DisplayName = "security:display_name";
    public const string DistinguishedName = "security:distinguished_name";
    public const string MatchedAdGroup = "security:matched_ad_group";
    public const string AuthorityLevel = "security:authority_level";
}
