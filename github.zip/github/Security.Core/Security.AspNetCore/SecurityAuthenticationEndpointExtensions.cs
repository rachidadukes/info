using Security.Core.Authentication;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Hosting;
using SecurityAuthenticationService = Security.Core.Authentication.IAuthenticationService;

namespace Security.AspNetCore;

public static class SecurityAuthenticationEndpointExtensions
{
    public static IEndpointRouteBuilder MapSecurityAuthenticationEndpoints(
        this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapPost("/auth/login", LoginAsync);
        endpoints.MapPost(
            "/auth/logout",
            (Func<HttpContext, Task<IResult>>)LogoutAsync).RequireAuthorization();

        return endpoints;
    }

    private static async Task<IResult> LoginAsync(
        [FromForm] LoginRequest request,
        SecurityAuthenticationService authenticationService,
        IWebHostEnvironment environment,
        HttpContext httpContext)
    {
        try
        {
            var result = await authenticationService.AuthenticateAsync(
                request.EmployeeId,
                request.Password,
                httpContext.RequestAborted);

            if (!result.Succeeded || result.User is null)
            {
                var failureCode = environment.IsDevelopment()
                    ? result.FailureCode
                    : AuthenticationFailureCode.AuthenticationFailed;
                return Results.Redirect(
                    $"/login?error={Uri.EscapeDataString(failureCode.ToString())}");
            }

            var principal = SecurityClaimsPrincipalFactory.Create(result.User);
            var properties = new AuthenticationProperties
            {
                AllowRefresh = true,
                IsPersistent = false,
                IssuedUtc = DateTimeOffset.UtcNow
            };

            await httpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                principal,
                properties);

            return Results.Redirect(GetSafeReturnUrl(request.ReturnUrl));
        }
        finally
        {
            request.Password = string.Empty;
        }
    }

    private static async Task<IResult> LogoutAsync(HttpContext httpContext)
    {
        await httpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Results.Redirect("/");
    }

    private static string GetSafeReturnUrl(string? returnUrl)
    {
        if (string.IsNullOrWhiteSpace(returnUrl) ||
            returnUrl.StartsWith("http", StringComparison.OrdinalIgnoreCase) ||
            returnUrl.StartsWith("//", StringComparison.Ordinal))
        {
            return "/";
        }

        return returnUrl.StartsWith("/", StringComparison.Ordinal)
            ? returnUrl
            : $"/{returnUrl}";
    }

    public sealed class LoginRequest
    {
        public string EmployeeId { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;

        public string? ReturnUrl { get; set; }
    }
}
