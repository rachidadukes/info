using System.Security.Claims;
using Security.Core.Models;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace Security.AspNetCore;

public static class SecurityClaimsPrincipalFactory
{
    public static ClaimsPrincipal Create(SecurityUser user)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.EmployeeId),
            new(ClaimTypes.Name, string.IsNullOrWhiteSpace(user.DisplayName) ? user.EmployeeId : user.DisplayName),
            new(ClaimTypes.Role, user.Role),
            new(SecurityClaimTypes.EmployeeId, user.EmployeeId),
            new(SecurityClaimTypes.DisplayName, user.DisplayName),
            new(SecurityClaimTypes.DistinguishedName, user.DistinguishedName),
            new(SecurityClaimTypes.MatchedAdGroup, user.MatchedAdGroup),
            new(SecurityClaimTypes.AuthorityLevel, user.AuthorityLevel.ToString())
        };

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        return new ClaimsPrincipal(identity);
    }
}
