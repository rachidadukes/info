using Security.Core.Models;

namespace Security.Core.Authentication;

public interface IAuthenticationService
{
    Task<AuthenticationResult> AuthenticateAsync(
        string employeeId,
        string password,
        CancellationToken cancellationToken = default);
}
