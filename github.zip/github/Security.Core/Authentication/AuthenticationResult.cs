using Security.Core.Models;

namespace Security.Core.Authentication;

public sealed record AuthenticationResult
{
    private AuthenticationResult(
        bool succeeded,
        SecurityUser? user,
        AuthenticationFailureCode failureCode,
        string? failureReason)
    {
        Succeeded = succeeded;
        User = user;
        FailureCode = failureCode;
        FailureReason = failureReason;
    }

    public bool Succeeded { get; }

    public SecurityUser? User { get; }

    public AuthenticationFailureCode FailureCode { get; }

    public string? FailureReason { get; }

    public static AuthenticationResult Success(SecurityUser user) =>
        new(true, user, AuthenticationFailureCode.None, null);

    public static AuthenticationResult Failed(
        AuthenticationFailureCode failureCode,
        string failureReason) => new(false, null, failureCode, failureReason);
}
