namespace Security.Core.Authorization;

public static class SecurityRoles
{
    public const string Developer = "Developer";
    public const string Admin = "Admin";
    public const string Clerk = "Clerk";
}
