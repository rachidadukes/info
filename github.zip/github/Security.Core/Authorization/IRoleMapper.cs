namespace Security.Core.Authorization;

public interface IRoleMapper
{
    SecurityRoleMatch? Map(IReadOnlyCollection<string> activeDirectoryGroups);
}
