using Security.Core.Options;

namespace Security.Core.Authorization;

public sealed class SecurityRoleMapper(SecurityAuthorizationOptions options) : IRoleMapper
{
    private readonly IReadOnlyList<SecurityGroupMapping> _mappings = options.GroupMappings
        .OrderBy(mapping => mapping.Precedence)
        .ToArray();

    public SecurityRoleMatch? Map(IReadOnlyCollection<string> activeDirectoryGroups)
    {
        foreach (var mapping in _mappings)
        {
            var matchedGroup = activeDirectoryGroups.FirstOrDefault(group =>
                IsMatch(group, mapping.DistinguishedName) ||
                IsMatch(group, mapping.GroupName) ||
                ContainsCommonName(group, mapping.GroupName));

            if (matchedGroup is not null)
            {
                return new SecurityRoleMatch(matchedGroup, mapping.Role, mapping.AuthorityLevel);
            }
        }

        return null;
    }

    private static bool IsMatch(string candidate, string configuredValue)
    {
        return !string.IsNullOrWhiteSpace(candidate) &&
            !string.IsNullOrWhiteSpace(configuredValue) &&
            string.Equals(candidate.Trim(), configuredValue.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    private static bool ContainsCommonName(string distinguishedName, string groupName)
    {
        if (string.IsNullOrWhiteSpace(distinguishedName) || string.IsNullOrWhiteSpace(groupName))
        {
            return false;
        }

        return distinguishedName.Contains($"CN={groupName}", StringComparison.OrdinalIgnoreCase);
    }
}
