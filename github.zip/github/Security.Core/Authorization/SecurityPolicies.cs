namespace Security.Core.Authorization;

public static class SecurityPolicies
{
    public const string DeveloperOnly = "Security.DeveloperOnly";
    public const string AdminOnly = "Security.AdminOnly";
    public const string ClerkOnly = "Security.ClerkOnly";
}
