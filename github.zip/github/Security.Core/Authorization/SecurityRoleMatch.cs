namespace Security.Core.Authorization;

public sealed record SecurityRoleMatch(
    string MatchedGroup,
    string Role,
    int AuthorityLevel);
