namespace Security.Core.Options;

public sealed class SecurityGroupMapping
{
    public string GroupName { get; init; } = string.Empty;

    public string DistinguishedName { get; init; } = string.Empty;

    public string Role { get; init; } = string.Empty;

    public int AuthorityLevel { get; init; }

    public int Precedence { get; init; }
}
