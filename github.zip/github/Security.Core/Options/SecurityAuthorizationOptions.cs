namespace Security.Core.Options;

public sealed class SecurityAuthorizationOptions
{
    public const string SectionName = "SecurityAuthorization";

    public IReadOnlyList<SecurityGroupMapping> GroupMappings { get; init; } = [];
}
