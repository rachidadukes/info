# Security.DirectoryTool

Console diagnostic tool for checking configured Active Directory role groups and users.

The tool uses the current Windows/domain credentials with LDAP Negotiate authentication. Run it from a work PC connected to the corporate network or VPN.

## Commands

Run with no arguments to open the interactive menu:

```powershell
dotnet run --project Security.DirectoryTool\Security.DirectoryTool.csproj
```

Show configured role mappings:

```powershell
dotnet run --project Security.DirectoryTool\Security.DirectoryTool.csproj -- groups
```

List users for a configured role:

```powershell
dotnet run --project Security.DirectoryTool\Security.DirectoryTool.csproj -- users Admin
```

Search for AD groups by keyword:

```powershell
dotnet run --project Security.DirectoryTool\Security.DirectoryTool.csproj -- search-groups Developer
```

Show the current Windows identity being used:

```powershell
dotnet run --project Security.DirectoryTool\Security.DirectoryTool.csproj -- whoami
```

Use a different config file:

```powershell
dotnet run --project Security.DirectoryTool\Security.DirectoryTool.csproj -- --config path\to\appsettings.json groups
```

Replace the placeholder values in `appsettings.json` once the real Active Directory group names are known.
