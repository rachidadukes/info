using Encore.Security.Core.Models;

namespace Encore.Security.Core.Authentication;

public interface IAuthenticationService
{
    Task<AuthenticationResult> AuthenticateAsync(
        string employeeId,
        string password,
        CancellationToken cancellationToken = default);
}
