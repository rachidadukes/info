namespace Encore.Security.Core.Authorization;

public sealed record EncoreRoleMatch(
    string MatchedGroup,
    string Role,
    int LegacyAuthorityLevel);
