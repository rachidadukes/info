using Encore.Security.Core.Options;

namespace Encore.Security.Core.Authorization;

public sealed class EncoreRoleMapper(EncoreAuthorizationOptions options) : IRoleMapper
{
    private readonly IReadOnlyList<EncoreGroupMapping> _mappings = options.GroupMappings
        .OrderBy(mapping => mapping.Precedence)
        .ToArray();

    public EncoreRoleMatch? Map(IReadOnlyCollection<string> activeDirectoryGroups)
    {
        foreach (var mapping in _mappings)
        {
            var matchedGroup = activeDirectoryGroups.FirstOrDefault(group =>
                IsMatch(group, mapping.DistinguishedName) ||
                IsMatch(group, mapping.GroupName) ||
                ContainsCommonName(group, mapping.GroupName));

            if (matchedGroup is not null)
            {
                return new EncoreRoleMatch(matchedGroup, mapping.Role, mapping.LegacyAuthorityLevel);
            }
        }

        return null;
    }

    private static bool IsMatch(string candidate, string configuredValue)
    {
        return !string.IsNullOrWhiteSpace(candidate) &&
            !string.IsNullOrWhiteSpace(configuredValue) &&
            string.Equals(candidate.Trim(), configuredValue.Trim(), StringComparison.OrdinalIgnoreCase);
    }

    private static bool ContainsCommonName(string distinguishedName, string groupName)
    {
        if (string.IsNullOrWhiteSpace(distinguishedName) || string.IsNullOrWhiteSpace(groupName))
        {
            return false;
        }

        return distinguishedName.Contains($"CN={groupName}", StringComparison.OrdinalIgnoreCase);
    }
}
