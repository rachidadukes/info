using Encore.Security.Core.Authorization;

namespace Encore.Security.Core.Options;

public static class EncoreDefaultGroupMappings
{
    public static IReadOnlyList<EncoreGroupMapping> All { get; } =
    [
        new()
        {
            GroupName = "BERCHA_Encore_Admin_Test",
            DistinguishedName = "CN=BERCHA_Encore_Admin_Test,OU=Groups-Test,OU=NFCUTEST,DC=NFCU,DC=NET",
            Role = EncoreRoles.Admin,
            LegacyAuthorityLevel = 1,
            Precedence = 1
        },
        new()
        {
            GroupName = "BERCHA_Encore_Super_Test",
            DistinguishedName = "CN=BERCHA_Encore_Super_Test,OU=Groups-Test,OU=NFCUTEST,DC=NFCU,DC=NET",
            Role = EncoreRoles.Supervisor,
            LegacyAuthorityLevel = 4,
            Precedence = 2
        },
        new()
        {
            GroupName = "BERCHA_Encore_Teller_Test",
            DistinguishedName = "CN=BERCHA_Encore_Teller_Test,OU=Groups-Test,OU=NFCUTEST,DC=NFCU,DC=NET",
            Role = EncoreRoles.Teller,
            LegacyAuthorityLevel = 5,
            Precedence = 3
        }
    ];
}
