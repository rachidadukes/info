using System.Security.Claims;
using Encore.Security.Core.Models;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace Encore.Security.AspNetCore;

public static class EncoreClaimsPrincipalFactory
{
    public static ClaimsPrincipal Create(EncoreUser user)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.EmployeeId),
            new(ClaimTypes.Name, string.IsNullOrWhiteSpace(user.DisplayName) ? user.EmployeeId : user.DisplayName),
            new(ClaimTypes.Role, user.Role),
            new(EncoreClaimTypes.EmployeeId, user.EmployeeId),
            new(EncoreClaimTypes.DisplayName, user.DisplayName),
            new(EncoreClaimTypes.DistinguishedName, user.DistinguishedName),
            new(EncoreClaimTypes.MatchedAdGroup, user.MatchedAdGroup),
            new(EncoreClaimTypes.LegacyAuthorityLevel, user.LegacyAuthorityLevel.ToString())
        };

        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        return new ClaimsPrincipal(identity);
    }
}
