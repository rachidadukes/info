using System.Text.Json.Serialization;

namespace LegalHoldAdmin.Models;

public sealed class MemberInquiryResponse
{
    [JsonPropertyName("NFCUResponseHeader")]
    public NfcuResponseHeader? NFCUResponseHeader { get; set; }

    [JsonPropertyName("member")]
    public Member? Member { get; set; }
}

public sealed class NfcuResponseHeader
{
    [JsonPropertyName("rsUID")]
    public string? RsUID { get; set; }

    [JsonPropertyName("consumerChannel")]
    public string? ConsumerChannel { get; set; }

    [JsonPropertyName("consumingApplicationName")]
    public string? ConsumingApplicationName { get; set; }

    [JsonPropertyName("confirmationNbr")]
    public string? ConfirmationNbr { get; set; }

    [JsonPropertyName("eor")]
    public string? Eor { get; set; }

    [JsonPropertyName("Status")]
    public Status? Status { get; set; }
}

public sealed class Status
{
    [JsonPropertyName("statusCode")]
    public string? StatusCode { get; set; }

    [JsonPropertyName("serverStatusCode")]
    public string? ServerStatusCode { get; set; }

    [JsonPropertyName("severity")]
    public string? Severity { get; set; }

    [JsonPropertyName("statusDesc")]
    public string? StatusDesc { get; set; }

    [JsonPropertyName("AdditionalStatus")]
    public List<AdditionalStatus> AdditionalStatus { get; set; } = new();
}

public sealed class AdditionalStatus
{
    [JsonPropertyName("statusCode")]
    public string? StatusCode { get; set; }

    [JsonPropertyName("serverStatusCode")]
    public string? ServerStatusCode { get; set; }

    [JsonPropertyName("severity")]
    public string? Severity { get; set; }

    [JsonPropertyName("statusDesc")]
    public string? StatusDesc { get; set; }
}

public sealed class Member
{
    [JsonPropertyName("accessNumber")]
    public string? AccessNumber { get; set; }

    [JsonPropertyName("floatName")]
    public string? FloatName { get; set; }

    [JsonPropertyName("membershipStatus")]
    public string? MembershipStatus { get; set; }

    [JsonPropertyName("membershipType")]
    public string? MembershipType { get; set; }

    [JsonPropertyName("origin")]
    public string? Origin { get; set; }

    [JsonPropertyName("originDesc")]
    public string? OriginDesc { get; set; }

    [JsonPropertyName("branchOfService")]
    public string? BranchOfService { get; set; }

    [JsonPropertyName("dateOfBirth")]
    public string? DateOfBirth { get; set; }

    [JsonPropertyName("dateOfMembership")]
    public string? DateOfMembership { get; set; }

    [JsonPropertyName("establishedDate")]
    public string? EstablishedDate { get; set; }

    [JsonPropertyName("createDate")]
    public DateTime? CreateDate { get; set; }

    [JsonPropertyName("lastUpdateDate")]
    public DateTime? LastUpdateDate { get; set; }

    [JsonPropertyName("language")]
    public string? Language { get; set; }

    [JsonPropertyName("personData")]
    public PersonData? PersonData { get; set; }

    [JsonPropertyName("w8CertificationCode")]
    public string? W8CertificationCode { get; set; }

    [JsonPropertyName("w8CertificationDate")]
    public string? W8CertificationDate { get; set; }

    [JsonPropertyName("backupWithholdingCode")]
    public string? BackupWithholdingCode { get; set; }

    [JsonPropertyName("nameLineTypCd1")]
    public string? NameLineTypCd1 { get; set; }

    [JsonPropertyName("nameLine1")]
    public string? NameLine1 { get; set; }

    [JsonPropertyName("emailAddresses")]
    public List<EmailAddress> EmailAddresses { get; set; } = new();

    [JsonPropertyName("phoneNumbers")]
    public List<PhoneNumber> PhoneNumbers { get; set; } = new();

    [JsonPropertyName("extensionValidInfo")]
    public Extensionvalidinfo? ExtensionValidInfo { get; set; }

    [JsonPropertyName("memberVerficationInfo")]
    public Memberverficationinfo? MemberVerficationInfo { get; set; }

    [JsonPropertyName("issuedIdentifications")]
    public List<Issuedidentification> IssuedIdentifications { get; set; } = new();

    [JsonPropertyName("financialData")]
    public List<Financialdata> FinancialData { get; set; } = new();

    [JsonPropertyName("employment")]
    public List<Employment> Employment { get; set; } = new();

    [JsonPropertyName("miscData")]
    public List<Miscdata> MiscData { get; set; } = new();

    [JsonPropertyName("postalAddress")]
    public List<PostalAddress> PostalAddress { get; set; } = new();

    [JsonPropertyName("contactHistory")]
    public List<Contacthistory> ContactHistory { get; set; } = new();

    [JsonIgnore]
    public string DisplayName => PersonData?.FullName ?? FloatName ?? string.Empty;

    [JsonIgnore]
    public string PrimaryEmail => EmailAddresses.FirstOrDefault()?.EmailAddressValue ?? string.Empty;

    [JsonIgnore]
    public string PrimaryPhone => PhoneNumbers.FirstOrDefault()?.PhoneNumberValue ?? string.Empty;
}

public sealed class PersonData
{
    [JsonPropertyName("fullName")]
    public string? FullName { get; set; }

    [JsonPropertyName("familyName")]
    public string? FamilyName { get; set; }

    [JsonPropertyName("givenName")]
    public string? GivenName { get; set; }

    [JsonPropertyName("preferredName")]
    public string? PreferredName { get; set; }

    [JsonPropertyName("dateOfBirth")]
    public string? DateOfBirth { get; set; }

    [JsonPropertyName("gender")]
    public string? Gender { get; set; }

    [JsonPropertyName("militaryRank")]
    public string? MilitaryRank { get; set; }

    [JsonPropertyName("militaryRankExtended")]
    public string? MilitaryRankExtended { get; set; }

    [JsonPropertyName("title")]
    public string? Title { get; set; }

    [JsonPropertyName("oedcode")]
    public string? Oedcode { get; set; }

    [JsonPropertyName("oedinstitution")]
    public string? Oedinstitution { get; set; }

    [JsonPropertyName("maritalStatus")]
    public string? MaritalStatus { get; set; }

    [JsonPropertyName("dependents")]
    public string? Dependents { get; set; }

    [JsonPropertyName("immigrationStatus")]
    public string? ImmigrationStatus { get; set; }

    [JsonPropertyName("w8CertificationCode")]
    public string? W8CertificationCode { get; set; }

    [JsonPropertyName("w8CertificationDate")]
    public string? W8CertificationDate { get; set; }

    [JsonPropertyName("backupWithholdingCode")]
    public string? BackupWithholdingCode { get; set; }

    [JsonPropertyName("nameLineTypCd1")]
    public string? NameLineTypCd1 { get; set; }

    [JsonPropertyName("nameLine1")]
    public string? NameLine1 { get; set; }

    [JsonPropertyName("bypassNameStdInd")]
    public string? BypassNameStdInd { get; set; }

    [JsonPropertyName("originatingBank")]
    public string? OriginatingBank { get; set; }

    [JsonPropertyName("originatingBranch")]
    public string? OriginatingBranch { get; set; }

    [JsonPropertyName("lastContactDate")]
    public string? LastContactDate { get; set; }

    [JsonPropertyName("holdingCompanyInd")]
    public string? HoldingCompanyInd { get; set; }

    [JsonPropertyName("internationalBusinessInd")]
    public string? InternationalBusinessInd { get; set; }

    [JsonPropertyName("empStatus")]
    public string? EmpStatus { get; set; }

    [JsonPropertyName("payRate")]
    public string? PayRate { get; set; }

    [JsonPropertyName("publiclyHeldInd")]
    public string? PubliclyHeldInd { get; set; }

    [JsonPropertyName("smallBusinessInd")]
    public string? SmallBusinessInd { get; set; }

    [JsonPropertyName("selfEmployedInd")]
    public string? SelfEmployedInd { get; set; }

    [JsonPropertyName("shareInformationCode")]
    public string? ShareInformationCode { get; set; }

    [JsonPropertyName("internetBankingInd")]
    public string? InternetBankingInd { get; set; }

    [JsonPropertyName("stockholderInd")]
    public string? StockholderInd { get; set; }

    [JsonPropertyName("lengthofOccupancy")]
    public string? LengthofOccupancy { get; set; }

    [JsonPropertyName("countryOfCitizenship")]
    public string? CountryOfCitizenship { get; set; }
}

public sealed class EmailAddress
{
    [JsonPropertyName("emailAddress")]
    public string? EmailAddressValue { get; set; }

    [JsonPropertyName("emailType")]
    public string? EmailType { get; set; }

    [JsonPropertyName("communicationId")]
    public string? CommunicationId { get; set; }

    [JsonPropertyName("preferredInd")]
    public string? PreferredInd { get; set; }
}

public sealed class PhoneNumber
{
    [JsonPropertyName("phoneSeqNumber")]
    public string? PhoneSeqNumber { get; set; }

    [JsonPropertyName("communicationId")]
    public string? CommunicationId { get; set; }

    [JsonPropertyName("phoneNumber")]
    public string? PhoneNumberValue { get; set; }

    [JsonPropertyName("formattedPhoneNumber")]
    public string? FormattedPhoneNumber { get; set; }

    [JsonPropertyName("phoneType")]
    public string? PhoneType { get; set; }

    [JsonPropertyName("phoneTypeDesc")]
    public string? PhoneTypeDesc { get; set; }

    [JsonPropertyName("preferredInd")]
    public string? PreferredInd { get; set; }
}

public class Extensionvalidinfo
{
    public string? statusCode { get; set; }
    public string? statusDesc { get; set; }
}

public class Memberverficationinfo
{
    public string? statusCode { get; set; }
    public string? statusDesc { get; set; }
}

public class Issuedidentification
{
    public string? type { get; set; }
    public string? number { get; set; }
    public string? description { get; set; }
    public string? verificationResults { get; set; }
    public string? tinCode { get; set; }
    public string? taxIdCertCode { get; set; }
}

public class Financialdata
{
    public string? type { get; set; }
    public string? amount { get; set; }
    public DateTime? lastUpdateDate { get; set; }
}

public sealed class Employment
{
    [JsonPropertyName("employerName")]
    public string? EmployerName { get; set; }

    [JsonPropertyName("annualIncome")]
    public string? AnnualIncome { get; set; }

    [JsonPropertyName("jobTitle")]
    public string? JobTitle { get; set; }

    [JsonPropertyName("employmentId")]
    public string? EmploymentId { get; set; }
}

public class Miscdata
{
    public string? type { get; set; }
    public string? value { get; set; }
}

public sealed class PostalAddress
{
    [JsonPropertyName("addressType")]
    public string? AddressType { get; set; }

    [JsonPropertyName("addressLine1")]
    public string? AddressLine1 { get; set; }

    [JsonPropertyName("addressLine2")]
    public string? AddressLine2 { get; set; }

    [JsonPropertyName("addressLine3")]
    public string? AddressLine3 { get; set; }

    [JsonPropertyName("city")]
    public string? City { get; set; }

    [JsonPropertyName("state")]
    public string? State { get; set; }

    [JsonPropertyName("zipCode")]
    public string? ZipCode { get; set; }

    [JsonPropertyName("countryCode")]
    public string? CountryCode { get; set; }

    [JsonPropertyName("addressId")]
    public string? AddressId { get; set; }

    [JsonPropertyName("foreignAddressInd")]
    public string? ForeignAddressInd { get; set; }

    [JsonPropertyName("printCountryInd")]
    public string? PrintCountryInd { get; set; }

    [JsonPropertyName("addressTypeInd")]
    public string? AddressTypeInd { get; set; }

    [JsonPropertyName("lastAddressMaintDt")]
    public string? LastAddressMaintDt { get; set; }

    [JsonPropertyName("mailCode")]
    public string? MailCode { get; set; }

    [JsonPropertyName("addressSubType")]
    public string? AddressSubType { get; set; }

    [JsonPropertyName("bypassAddrFormatInd")]
    public string? BypassAddrFormatInd { get; set; }

    [JsonPropertyName("addressSourceCd")]
    public string? AddressSourceCd { get; set; }
}
public class Contacthistory
{
    public string? phoneNumber { get; set; }
    public string? contactName { get; set; }
    public string? jobTitle { get; set; }
    public Contactmiscdata[] contactMiscData { get; set; } = Array.Empty<Contactmiscdata>();
}

public class Contactmiscdata
{
    public string? type { get; set; }
    public string? value { get; set; }
}
